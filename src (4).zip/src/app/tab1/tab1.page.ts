import { Component } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Urls } from '../constants/urls';
import { ToastController } from '@ionic/angular';
import { AuthService } from '../auth.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  flag = false;
  user: any = JSON.parse(localStorage.getItem('currentUser'));
  loggedInUser: string;

  constructor(
    private authService: AuthService,
    private http: HttpClient, private router: Router,
    public toastController: ToastController
  ) {
    // LoopBackConfig.setBaseURL("http://192.168.0.117:3000");
  }
  storage;
  id: string;
  token: string;
  centerData: any;
  UserCenter: any;
  wasteCollected: any;
  allcenter: any;
  currentUserName: any;
  w: any;
  role: any;
  ngOnInit() {
    this.centerData = {
      "centerName": "",
      "totalCollection": "",
      "userName": "",
      "wasteCollected": []
    }
    this.w = {
      "center": "center",
      "centerId": "string",
      "id": "string",
      "waste": [{}]
    }
    this.allcenter = [];
    this.storage = JSON.parse(localStorage.getItem("currentUser"));
    // console.log(this.storage);
    this.id = this.storage.userId;
    this.token = this.storage.id;
    // this.getuser("")

  }
  getuser(e) {
    this.http.get(`${Urls.USERS}/${this.id}?access_token=${this.token}`).subscribe((res: any) => {
      this.UserCenter = res.centers;
      // console.log(this.UserCenter)
      if (res.role === 'admin') {
        this.role = true;
      }
      this.getCenterData(e);
    })
  }

  ionViewWillEnter(e) {
    this.getuser("")
    this.allcenter = [];
  }

  //  getCenterData() {
  //      this.http.get(`${Urls.CENTERS}/${this.UserCenter}`).subscribe(res => {
  //     this.centerData = res;
  //     console.log(this.centerData);
  //     this.centerData.userName.forEach(username => {
  //       if(username.id === this.user.userId) {
  //         this.loggedInUser = username.name;
  //       }
  //     });
  //     this.wasteCollected = this.centerData.wasteCollected;
  //     this.presentToast('Successfully Loaded data', 'success', '2000')
  //   },
  //     err => {
  //       console.log(err)
  //       this.presentToast('Some error occured while connecting to database', 'danger', '200')
  //     })
  // }
  getCenterData(e) {
    for (let i = 0; i < this.UserCenter.length; i++) {
      this.http.get(`${Urls.CENTERS}/${this.UserCenter[i]}`).subscribe(res => {
        this.centerData = res;
        this.allcenter.push(res);
        this.presentToast('Successfully Loaded data', 'success', '2000')
        if (e) {
          e.target.complete();
        }

      },
        err => {
          console.log(err)
          this.presentToast('Some error occured while connecting to database', 'danger', '200')
        })

        console.log(this.allcenter)
    }

  }


  onClickCenData(cen, ev) {
    console.log(cen, ev)

    // ev.target.color = 'warning';
    // this.wasteCollected = cen.wasteCollected;
    console.log(cen, this.wasteCollected)
    this.http.get(`${Urls.CENTERS}/${cen.id}/wastecollecteds`).subscribe(res => {
      this.flag = true;
      this.w = res;
      this.wasteCollected = this.w.waste;
      console.log(res)
    }, err => { this.flag = false; this.presentToast('No data avalaible', 'danger', '800') })
    for (let i = 0; i < cen.userName.length; i++) {
      if (this.id == cen.userName[i].id) {
        this.currentUserName = cen.userName[i].name;
      }
    }
  }
  onMenu() {
    console.log("menu clicked")
    this.router.navigate(['/menu']);
  }

  async presentToast(d, c, t) {
    const toast = await this.toastController.create({
      message: d,
      duration: t,
      position: 'top',
      cssClass: 'normalToast',
      color: c
    });
    toast.present();
  }
  onLogout() {
    this.authService.logout();
  }

  doRefresh(event) {
    console.log('Begin async operation');
    this.ionViewWillEnter(event)
    this.wasteCollected = null
    setTimeout(() => {
      console.log('Async operation has ended');
      event.target.complete();
    }, 1000);
  }
  close() {
    this.flag = false;
  }
  edit(d, i) {
    console.log(d, i)
  }

}
