import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddexpenseComponent } from './addexpense/addexpense.component';

import { ExpensesPage } from './expenses.page';

const routes: Routes = [
  {
    path: '',
    component: ExpensesPage,
  },
  {
    path: 'add-expense',
    component: AddexpenseComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ExpensesPageRoutingModule {}
