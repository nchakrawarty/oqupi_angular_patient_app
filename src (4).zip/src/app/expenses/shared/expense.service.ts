import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Urls } from 'src/app/constants/urls';
import { Expense } from './expense.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExpenseService {

  expenses:Expense[];

  centerId: string;

  months = ["January", "February", "March", "April", "May", "June", 
            "July", "August", "September", "October", "November", "December"];
  

  constructor(
    private http: HttpClient
  ) { }


  setCenterName() {
    this.centerId = localStorage.getItem('selectedCenterId');
    return this.http.get(`${Urls.CENTERS}/${this.centerId}`);
  }

  getExpenses() {
    this.centerId = localStorage.getItem('selectedCenterId');
    return this.http.get(`${Urls.CENTERS}/${this.centerId}/expenses`);
    // return this.expenses = [
    //   {
    //     name: 'Printing',
    //     desc: 'Printed bill books at abc printers',
    //     amount: 200,
    //     centerId: '5f2953d5bc955c29d9df0e06',
    //     date: new Date(2021, 0)
    //   },
    //   {
    //     name: 'Stationary',
    //     desc: 'Bought A4 papers for office work',
    //     amount: 350,
    //     centerId: '5f2953d5bc955c29d9df0e06',
    //     date: new Date(2021, 2)
    //   },
    //   {
    //     name: 'Fuel',
    //     desc: 'Fuel costs for sales team',
    //     amount: 1000,
    //     centerId: '5f6ddd65bc955c29d9df0e09',
    //     date: new Date(2021, 2)
    //   },
    //   {
    //     name: 'Stationary',
    //     desc: 'Bought pen for office work',
    //     amount: 50,
    //     centerId: '5f93b04f93be19a1ee2d025a',
    //     date: new Date(2021, 2)
    //   },
    //   {
    //     name: 'Miscelenious',
    //     desc: 'Some cost',
    //     amount: 500,
    //     centerId: '5f93b07f93be19a1ee2d025b',
    //     date: new Date(2021, 1)
    //   }
    // ];
  }

  postExpense (expense) {
    return this.http.post(Urls.EXPENSE, expense);
  }

  patchExpense(expense, id, a) {
    console.log(expense);
    console.log(a);
    console.log(id);
    // return this.http.patch(`${Urls.EXPENSE}/${id}`, expense);
  }

  fetchCenters(id, token) {
    return this.http.get(`${Urls.USERS}/${id}?access_token=${token}`);
  }

  getAllCenters(id) {
    return this.http.get(`${Urls.CENTERS}/${id}`);
  }
}
