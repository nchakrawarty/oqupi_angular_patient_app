export interface Expense {
    id:number,
    name:string,
    type?:string,
    desc:string,
    amount:number,
    date:Date
  };