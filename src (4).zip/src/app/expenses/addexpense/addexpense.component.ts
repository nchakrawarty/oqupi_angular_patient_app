import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { Expense } from '../shared/expense.model';
import { ExpenseService } from '../shared/expense.service';



@Component({
  selector: 'app-addexpense',
  templateUrl: './addexpense.component.html',
  styleUrls: ['./addexpense.component.scss'],
})
export class AddexpenseComponent implements OnInit {

  date:Date = new Date();

  expenses: any;
  expense: Expense = {
    name: null,
    desc: null,
    type: null,
    amount: null,
    id: null,
    date: null
  }
  exType: any = [];

  constructor(
    private router: Router,
    private expenseService: ExpenseService,
    private toastController: ToastController
  ) { }

  ngOnInit() {
    this.getAllExpenses();
    // this.expenses=this.expenseService.getExpenses();
  }

  async ionViewWillEnter() {
    // this.expenses=this.expenseService.getExpenses();
    await this.getAllExpenses();
  }

  // Open Menu
  onMenu() {
    this.router.navigate(['menu']);
  }

  async getAllExpenses() {
    await this.expenseService.getExpenses().subscribe(res => {
      this.expenses = res;
      if(this.expenses) {
        this.expenses.expenses.forEach(expense => {
          this.exType.push(expense.name);
        });
        this.exType = [...new Set(this.exType)];
      }
      console.log(this.exType);
    })
    // await this.expenseService.getExpenses().subscribe(res => {
    //   this.expenses = res;
    // });
  }

  // back to view expenses page
  back() {
    this.router.navigate(['/expenses']);
  }

  async checkCenterExpenses() {
    await this.expenseService.getExpenses().subscribe(res => {
      this.expenses = res;
    });
  }

  logForm() {
    console.log(this.expenses);
    let expn: any = {};
    expn.centerId = localStorage.getItem('selectedCenterId');
    if(this.expense.type && this.expense.type !== '') {
      this.expense.name = this.expense.type;
    } 
    delete this.expense.type;

    if(this.expense.amount 
        && this.expense.date 
        && this.expense.desc 
        && this.expense.name
      ) {
        if(this.expenses && this.expenses.expenses.length > 0) {
          console.log('PUSH');
          this.expense.id = this.expenses.expenses.length + 1;
          expn.expenses = this.expenses.expenses;
          expn.expenses.push(this.expense);
          this.expenseService.patchExpense(this.expenses, this.expenses.centerId, expn);
        } else {
          expn.expenses = [];
          this.expense.id = 0;
          expn.expenses.push(this.expense);
          console.log(expn);
          this.expenseService.postExpense(expn).subscribe(res => {
            console.log(res);
            this.presentToast('Successs', 'success');
            this.expense = {
              name: null,
              id: null,
              desc: null,
              type: null,
              amount: null,
              date: null
            }
          })
        }
       
    } else {
      this.presentToast('Please enter all fields', 'danger');
    }
   
  }


  async presentToast(d, c) {
    const toast = await this.toastController.create({
      message: d,
      duration: 1000,
      position: 'top',
      cssClass: 'normalToast',
      color: c
    });
    toast.present();
  }

}
