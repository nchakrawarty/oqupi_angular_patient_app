import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AlluserslistPage } from './alluserslist.page';

const routes: Routes = [
  {
    path: '',
    component: AlluserslistPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AlluserslistPageRoutingModule {}
