import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  users: any;

  constructor(private authService: AuthService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {}
  
  login(v) {
    this.authService.login(v.form.value.email, v.form.value.password)
      .subscribe(
        data => {

          // if (this.returnUrl === '/') {
          //   this.returnUrl = '/dashboard';
          // } else {
          //   console.log(data, this.returnUrl);

          // }
          // this.router.navigate([this.returnUrl]);
          console.log(data);

        },
        error => {
          console.log(error, v);
        });
  }

}
