import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { TripsViewPage } from './trips-view.page';

describe('TripsViewPage', () => {
  let component: TripsViewPage;
  let fixture: ComponentFixture<TripsViewPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TripsViewPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(TripsViewPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
