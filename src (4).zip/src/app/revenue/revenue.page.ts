import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { ActivatedRoute, Router } from '@angular/router';
import { ModalController, ToastController } from '@ionic/angular';

import { Urls } from '../constants/urls';
import { EditrevenueComponent } from './editrevenue/editrevenue.component';
import { RevenueService } from './shared/revenue.service';
import { Customer } from './shared/Customer';
import { Revenue } from './shared/Revenue';

@Component({
  selector: 'app-revenue',
  templateUrl: './revenue.page.html',
  styleUrls: ['./revenue.page.scss'],
})
export class RevenuePage implements OnInit {

  data: any = [];
  filteredData: any = [];
  savedby: string;
  centers:any = [];
  panchayats:any = [];
  selectedPanchayat:string = null;

  selectedCenter: string = null;

  paid = false;

  searchTerm = '';

  revenue:Revenue = {
    centerId: null,
    customerId: null,
    date: null,
    engname: null,
    kannadaname: null,
    area: null,
    doorno: null,
    phone: null,
    address: null,
    amount: null,
    type: null,
    editDate: null,
    createdAt: new Date(),
    id: null
  };

  customer:Customer = {
    engname: null,
    kannadaname: null,
    contact: null,
    address: null,
    area: null,
    amount: null,
    panchayat: null,
    type: null,
    doorno: null,
    editDate: null,
    createdAt: null,
    id: null,
    centerId: null
  }

  today = new Date();
  months = ["January", "February", "March", "April", "May", "June", 
            "July", "August", "September", "October", "November", "December"];

  month = this.months[this.today.getMonth()];

  temp:any = [];
  center: any = [];
  role:boolean = false;

  constructor(
    private http: HttpClient, 
    private route: ActivatedRoute, 
    private router: Router,
    private revenueService: RevenueService,
    public modalController: ModalController,
    private toastController: ToastController
  ) {}
  
  ngOnInit() {
  }

  async ionViewWillEnter() {
    this.selectedCenter = localStorage.getItem('selectedCenterId');
    await this.revenueService.setCenterName().subscribe(res => {
      this.center = res;
    });
    this.initialData();
  }

  async initialData(month:number = null, year:number = null) {
    this.data = [];
    this.centers = [];
    this.filteredData = [];
    let user = await JSON.parse(localStorage.getItem('currentUser'));
    let userId = user.userId;
    let token = user.id;
    this.revenueService.getUser(userId, token)
      .subscribe((res:any) => {
        const centerIds: [] = res.centers;
        let selectedCenter = res.centers[0];
        localStorage.setItem('selectedCenterId', selectedCenter);
        if (res.role === 'admin') {
          this.role = true;
          this.fetchAllCenternames(centerIds);
        }
      });
    this.http.get(`${Urls.CENTERS}/${this.selectedCenter}/customers`).subscribe(res => {
      this.temp = res;
      console.log(`${Urls.CENTERS}/${this.selectedCenter}/customers`);
      this.temp.forEach(dt => {
        let tempData:any = {};
        tempData = dt;
        this.http.get(`${Urls.CENTERS}/${this.selectedCenter}/customers/${dt.id}/revenues`).subscribe(
          (rs:any) => {
            if(rs.length === 1) {
              let dte = rs[0].date.split('-');
              tempData.revenue = rs[0];

              if(month !== null && year !== null) {
                if(parseInt(dte[0]) === year
                 && parseInt(dte[1]) === month) {
                  tempData.revenue.paid = true;
                } else {
                  tempData.revenue.paid = false;
                }
              } else {
                if(parseInt(dte[0]) === this.today.getFullYear()
                 && parseInt(dte[1]) === this.today.getMonth()+1) {
                  tempData.revenue.paid = true;
                } else {
                  tempData.revenue.paid = false;
                }
              }
              
              this.data.push(tempData);
              this.filteredData.push(tempData);
            }
            else if(rs.length > 1) {
              rs.forEach(itm => {
                let dte = itm.date.split('-');
                if(parseInt(dte[0]) === this.today.getFullYear()
                 && parseInt(dte[1]) === this.today.getMonth()+1) {
                  if(itm && itm.id) {
                    itm.paid = true;
                    tempData.revenue = itm;
                    this.data.push(tempData);
                    this.filteredData.push(tempData);
                  }
                 }
              });
            }
            else {
              tempData.revenue = {};
              tempData.revenue.paid = false;
              this.data.push(tempData);
              this.filteredData.push(tempData);
            }
          },
          (err) => {
            console.error(err);
            // dt.paid = false;
            // this.data.push(dt)
          }
        );
      });
    });
  }

  // Fetch All Centernames
  fetchAllCenternames(ids) {
    ids.forEach(id => {
      this.revenueService.getCenters(id)
        .subscribe((res:any) => {
          this.centers.push(res)
        });
    });
  }

  monthChanged() {
    let dt:string[] = this.month.split('-');
    let monthNumber = parseInt(dt[1]);
    let yearNumber = parseInt(dt[0]);

    let tempData:any = [] ;
    this.filteredData = this.data;

    this.initialData(monthNumber, yearNumber);
  }

  // Fetch All Panchayats in a center
  // fetchPanchayats() {
  //   this.http.get(`${Urls.CENTERS}/${this.id}`).subscribe((res:any) => {
  //     console.log(res);
  //     this.panchayats = res.panchayats;

  //     if(!localStorage.getItem('selectedPanchayat')) {
  //       localStorage.setItem('selectedPanchayat', this.panchayats[0]);
  //     }

  //     this.selectedPanchayat = localStorage.getItem('selectedPanchayat');
  //   })
  // }

  // Select Center Option
  select(e) {
    this.selectedCenter =  e.target.value;
    localStorage.setItem('selectedCenterId', e.target.value);
    this.initialData();
  }

   // Open menu
    onMenu() {
      this.router.navigate(['/menu']);
    }

    // Save existing users' data
    saveUserPayment(user) {
      // console.log(user);
      this.presentModal(user);
    }

    // Navigate back to Add page
    add() {
      this.router.navigate([`/revenue/add-revenue`]);
    }

    back() {
      this.router.navigate(['/']);
    }

    async presentModal(payment) {
      const modal = await this.modalController.create({
        component: EditrevenueComponent,
        componentProps: {
          'userData': payment
        },
        cssClass: 'my-custom-class'
      },
      );
     modal.onWillDismiss()
      .then((val) => {
        // console.log(val.data.data);
        if(val.data.data) {
          let data = Object.assign({}, val.data.data);
          let customerId = data.id;
          let revenueId = data.revenue.id;
          let amount = data.revenue.amount;

          this.customer = Object.assign({}, data);
          delete data.revenue;
          this.revenue = data;
          this.revenue.amount = amount;
          this.revenue.customerId = customerId;
          this.revenue.id = revenueId;
          
          delete this.customer.revenue;

          // console.log(this.customer);
          // console.log(this.revenue);

          // this.revenueService.patchCustomers(this.customer);
          // this.revenueService.checkRevenueById(this.customer.centerId, customerId, this.revenue).subscribe(
          //   (res:any) => {
          //     if(res.length > 0) {
          //       res.forEach(itm => {
          //         if(itm.id === this.revenue.id) {
          //           this.revenueService.patchRevenues(this.revenue, itm.id);
          //         }
          //       });
          //     } else {
          //       this.revenue.date = this.revenue.editDate;
          //       console.log(this.revenue);
          //       this.revenueService.postRevenues(this.revenue);
          //     }
          //   },
          //   err => {
          //     if(err.status === 404) {
          //       this.revenue.date = this.revenue.editDate;
          //       console.log(this.revenue);
          //       this.revenueService.postRevenues(this.revenue);
          //     }
          //   }
          // )
          
          this.revenueService.patchCustomers(this.customer).subscribe(
            res => {
              if(this.customer.centerId && customerId) {
                this.revenueService.checkRevenueById(this.customer.centerId, customerId, this.revenue)
                .subscribe(
                  (rs1:any) => {
                    if(rs1.id) {
                      this.revenueService.patchRevenues(this.revenue, rs1.id).subscribe(
                        rs2 => {
                          this.presentToast('Successfully Edited Revenue', 'success');
                        }
                      );
                    }
                  },
                  err => {
                    if(err.status === 404) {
                      this.revenue.date = this.revenue.editDate;
                        this.revenueService.postRevenues(this.revenue).subscribe(
                          rs3 => {
                            this.presentToast('Successfully Added Revenue', 'success');
                          }
                        );
                    } else {
                      this.presentToast('Some error occured!', 'danger');
                    }
                  }
                );
              }
            }
          );
        }
        this.ionViewWillEnter();
      });

      return await modal.present();
    }

    doRefresh(event) {
      this.initialData();
      setTimeout(() => {
        event.target.complete();
      }, 1000);
    }

    async presentToast(d, c) {
      const toast = await this.toastController.create({
        message: d,
        duration: 1000,
        position: 'top',
        cssClass: 'normalToast',
        color: c
      });
      this.initialData();
      toast.present();
    }

}