export interface Revenue {
    centerId: string,
    customerId: string,
    panchayat?: string,
    date: string,
    engname: string,
    kannadaname: string,
    area: string,
    doorno: string,
    phone: string,
    address: string,
    amount: number,
    type: string,
    editDate: string,
    createdAt: Date,
    id: string
}