import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Urls } from 'src/app/constants/urls';

@Injectable({
  providedIn: 'root'
})
export class RevenueService {

  constructor(private http: HttpClient) { }

  // Get Selected Center ID
  getCenterId() {
    let id = localStorage.getItem('selectedCenterId');
    return id;
  }

  // Set Center name
  setCenterName() {
   let centerId= localStorage.getItem('selectedCenterId');
    return this.http.get(`${Urls.CENTERS}/${centerId}`);
  }

  // Get logged in user's details
  getUser(id, token) {
    return this.http.get(`${Urls.USERS}/${id}?access_token=${token}`);
  }

  // Get all centers associated with the loggedin user
  getCenters(id) {
    return this.http.get(`${Urls.CENTERS}/${id}`)
  }

  // Post Customers
  postCustomers(customer) {
    return this.http.post(Urls.CUSTOMERS, customer);
  }

  // Patch Customers
  patchCustomers(customer) {
    let id = '';
    if(customer.customerId) {
       id = customer.customerId;
    }
    else {
      id = customer.id;
    }
    delete customer.id;
    delete customer.paid;
    delete customer.amount;
    delete customer.customerId;
    delete customer.paid;
    delete customer.date;
    console.log(customer);
    console.log(id);
    return this.http.patch(`${Urls.CUSTOMERS}/${id}`, customer);
  }

  checkRevenueById(centerId, customerId, revenue) {
    console.log(centerId, customerId);
    console.log(revenue);
    return this.http.get(`${Urls.CENTERS}/${centerId}/customers/${customerId}/revenues/${revenue.id}`);
  }

  // Post Revenues
  postRevenues(revenue) {
    delete revenue.id;
    console.log(revenue);
    return this.http.post(Urls.REVENUE, revenue);
  }

  // Post Revenues
  patchRevenues(revenue, id) {
    delete revenue.id;
    console.log(revenue);
    console.log(id);
    return this.http.patch(`${Urls.REVENUE}/${id}`, revenue);
  }

}
