import { Component, OnInit } from '@angular/core';
import { ModalController, NavParams } from '@ionic/angular';

@Component({
  selector: 'app-wasteinput',
  templateUrl: './wasteinput.component.html',
  styleUrls: ['./wasteinput.component.scss'],
})
export class WasteinputComponent implements OnInit {
  modalTitle: string;
  modelValue: number;
  modelRemark: string;

  dataValue: any;
  today = new Date();
  constructor(
    private modalController: ModalController,
    public navParams: NavParams
  ) { }

  ngOnInit() {
    // console.table(this.navParams.data);
    // this.name = this.navParams.data[0];
    this.dataValue = {
      "name": this.navParams.data.name,
      "value": this.navParams.data.value
    }
    this.modelValue = null;
    console.log(this.dataValue)
  }

  async closeModal() {
    // this.dataValue[this.navParams.data.name] = this.modelValue;
    this.dataValue.value = this.modelValue;
    // console.table(this.navParams.data);
    const onClosedData: Object = this.dataValue;
    await this.modalController.dismiss(onClosedData);
  }

  async closeModalNodata() {
    await this.modalController.dismiss();
  }


}
