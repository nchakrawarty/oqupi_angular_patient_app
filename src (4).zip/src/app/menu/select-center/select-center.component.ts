import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { ActivatedRoute, Router } from '@angular/router';
import { Urls } from '../../constants/urls';

@Component({
  selector: 'app-select-center',
  templateUrl: './select-center.component.html',
  styleUrls: ['./select-center.component.scss'],
})
export class SelectCenterComponent implements OnInit {

  id: string;
  storage: any;
  allCenterIds: [];
  allCenters: any;
  selectedcenter: string;
  token: string;
  UserCenter: any;
  role: boolean = false;

  constructor(private http: HttpClient) {}

  /** START CENTER SELECTION **/

  async ngOnInit() {
    this.storage = await JSON.parse(localStorage.getItem("currentUser"));
    this.id = this.storage.userId;
    this.token = this.storage.id;
    console.log("RES: ");
    this.getUserCenters();
  }

  ionViewWillEnter() {
    this.getAllCenters();
  }

  getUserCenters() {
    this.http.get(`${Urls.USERS}/${this.id}?access_token=${this.token}`).subscribe((res: any) => {
      this.allCenterIds = res.centers;
      if(localStorage.getItem('selectedCenterId').length <= 0) {
        this.UserCenter = res.centers[0];
      }
      else {
        this.UserCenter = localStorage.getItem('selectedCenterId');
      }
      
      localStorage.setItem('selectedCenterId', this.UserCenter);
      if (res.role === 'admin') {
        this.role = true;
        this.getAllCenters();
      }
    })
  }

  onChange(v) {
    console.log(v.detail.value)
    localStorage.setItem('selectedCenterId', v.detail.value);
    // this.fetchCenterData(v.detail.value, "");
    this.ionViewWillEnter();
  }

  getAllCenters() {
    let centers = []
    this.allCenterIds.forEach(async id => {
      await this.http.get(`${Urls.CENTERS}/${id}`).subscribe(res => {
        console.log(res);
        centers.push(res);
      });
    });
    this.allCenters = centers;
    console.log(this.allCenters);
  }

}
