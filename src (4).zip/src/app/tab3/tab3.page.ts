import { Component } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { ModalController, NavParams } from '@ionic/angular';
import { WasteinputComponent } from '../wasteinput/wasteinput.component';
import { ToastController } from '@ionic/angular';
import { Urls } from '../constants/urls';
import { $ } from 'protractor';
@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
  constructor(
    private http: HttpClient,
    public modalController: ModalController,
    public toastController: ToastController
  ) {
  }
  storage;
  id: string;
  token: string;
  centerData: any;
  centersData: any;
  UserCenter: any;
  wasteCollected: any;
  wastecollection: any;
  typeOfWaste: any;
  valueOfWaste: any;
  dataReturned: any;
  data: any;
  total: number = 0;
  oveAll: number = 0;

  currentDate: String;
  weekdays = ["sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

  async ngOnInit() {
    this.centerData = {
      "centerName": "",
      "totalCollection": "",
      "userName": "",
      "wasteCollected": []
    }
    this.wastecollection = {
      center: "",
      waste: [],
      centerId: ""
    };
    this.wasteCollected = {
      "day": "",
      "date": "",
      "totalShift": 0,
      "totalwaste": 0,
      "waste": ""
    }

    this.valueOfWaste = [];
    this.storage = await JSON.parse(localStorage.getItem("currentUser"));
    this.id = this.storage.userId;
    this.token = this.storage.id;
    this.getUserCenters();
  }

  getUserCenters() {
    this.http.get(`${Urls.USERS}/${this.id}?access_token=${this.token}`).subscribe((res: any) => {
      this.UserCenter = res.centers[0];
      if(!localStorage.getItem('selectedCenterId')) {
        localStorage.setItem('selectedCenterId', this.UserCenter);
      }
      // this.fetchCenterData(localStorage.getItem('selectedCenterId'));
    })
  }

  async ionViewWillEnter() {
    this.typeOfWaste = [
      {
        "name": "Plastic",
        "value": 0,
        "delete": ""
      },
      {
        "name": "Paper",
        "value": 0,
        "delete": ""
      },
      {
        "name": "Metal",
        "value": 0,
        "delete": ""
      },
      {
        "name": "Glass",
        "value": 0,
        "delete": ""
      },
      {
        "name": "Other dry waste",
        "value": 0,
        "delete": ""
      },
      {
        "name": "Vegetable & fruit peels",
        "value": 0,
        "delete": ""
      },
      {
        "name": "Egg shells",
        "value": 0,
        "delete": ""
      },
      {
        "name": "Chicken & fish bones",
        "value": 0,
        "delete": ""
      },
      {
        "name": "Rotten fruits & vegetables",
        "value": 0,
        "delete": ""
      },
      {
        "name": "Tissue paper soiled with food",
        "value": 0,
        "delete": ""
      },
      {
        "name": "Tea bags & Coffee grinds",
        "value": 0,
        "delete": ""
      },
      {
        "name": "Leaf plates",
        "value": 0,
        "delete": ""
      }
    ];

    this.fetchCenterData(localStorage.getItem('selectedCenterId'));
    this.currentDate = new Date().toISOString();
  }

  fetchCenterData(v) {
    this.http.get(`${Urls.CENTERS}/${v}`).subscribe(res => {
      this.centersData = res;
      this.fetchData(v);
    });
  }

  fetchData(v) {
    this.http.get(`${Urls.CENTERS}/${v}/wastecollecteds`).subscribe(res => {
      this.data = res;
      console.log(this.data);
      this.data.waste.forEach(item => {
        item.waste.forEach(element => {
          this.typeOfWaste.forEach(wastetype => {
            if (wastetype.name === element.name) {
              // console.log("Name " + wastetype.name + "=" + wastetype.value, element.value)
              wastetype.value = parseFloat(wastetype.value) + parseFloat(element.value);
              return false;
            }
          });
        });
      });
    });
  }

  saveCenterData() {
    this.wasteCollected.day = this.weekdays[new Date().getDay()];
    this.wasteCollected.date = (new Date()).toISOString().slice(0, 19).replace(/-/g, "/").replace("T", " at ");
    this.http.get(`${Urls.CENTERS}/${localStorage.getItem('selectedCenterId')}`).subscribe(res => {
      this.centerData = res;
      this.centerData.totalSold = parseFloat(this.centerData.totalSold) + this.wasteCollected.totalwaste;
      // this.centerData.wasteCollected.unshift(this.wasteCollected);
      this.wasteCollected.savedBy = localStorage.getItem('userName');
      this.data.waste.unshift(this.wasteCollected);
      console.log(this.data);
      if (this.valueOfWaste.length > 0) {
        console.log(this.data);
        this.http.patch(`${Urls.WASTE}/${this.data.id}`, this.data).subscribe(res => {
          this.wasteCollected = {
            "day": "",
            "date": "",
            "totalShift": 0,
            "totalwaste": 0,
            "waste": ""
          }

          this.http.patch(`${Urls.CENTERS}/${localStorage.getItem('selectedCenterId')}`, this.centerData).subscribe(res => {
          })

          this.valueOfWaste = [];
          this.presentToast('Successfully sold', 'success');
          this.ionViewWillEnter();
        })
      } else {
        this.presentToast('Please add atleast one data to sell', 'danger')
      }
    },
      err => {
        console.log(err)
        this.presentToast('Connection error, check internet', 'danger')
      })
  }
  onClickSaveData() {
    let flag = true;
    this.typeOfWaste.forEach(waste => {
      this.valueOfWaste.forEach(val => {
        if(waste.name === val.name) {
          if(waste.value >= val.value) {
            val.value = -Math.abs(val.value);
            this.presentToast('Success', 'success')
          } else {
            flag = false;
            this.presentToast("Sell value can't be greater than total value", 'danger')
          }
          return;
        }
      });
    });

    // this.valueOfWaste.forEach(element => {
    //   element.value = -Math.abs(element.value);
    // });
    if(flag) {
      this.wasteCollected.waste = this.valueOfWaste;
      for (var i = 0; i < this.valueOfWaste.length; i++) {
        this.wasteCollected.totalwaste = parseFloat(this.wasteCollected.totalwaste) + parseFloat(this.valueOfWaste[i].value);
      }
      this.saveCenterData();
    }
  }
  modal(e, w) {
    this.presentModal(w)
  }
  async presentModal(w) {
    const modal = await this.modalController.create({
      component: WasteinputComponent,
      componentProps: w
    });
    modal.onDidDismiss().then((dataReturned) => {
      if (dataReturned !== null && dataReturned.data !== undefined) {
        this.dataReturned = dataReturned.data;
        if (this.valueOfWaste.length > 0) {
          let count = -1;
          for (var i = 0; i < this.valueOfWaste.length; i++) {
            if (this.valueOfWaste[i].name == dataReturned.data.name) {
              count = i;
            }
          }
          if (count >= 0) {
            this.valueOfWaste[count].value = dataReturned.data.value;
          } else {
            this.valueOfWaste.push(dataReturned.data)
          }
        } else {
          this.valueOfWaste.push(dataReturned.data)
        }
        w.delete = dataReturned.data.value;
      }
    });
    return await modal.present();
  }
  async presentToast(d, c) {
    const toast = await this.toastController.create({
      message: d,
      duration: 1000,
      position: 'top',
      cssClass: 'normalToast',
      color: c
    });
    toast.present();
  }
}