import { Component, OnInit } from '@angular/core';
import { Urls } from '../constants/urls';
import { HttpClient } from "@angular/common/http";
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-addcenter',
  templateUrl: './addcenter.page.html',
  styleUrls: ['./addcenter.page.scss'],
})
export class AddcenterPage implements OnInit {
  usercenter: any;
  allCenter: any;
  panchayat: any;
  flag = false;
  storage;
  id: string;
  token: string;
  name: string;
  newUser = { "name": "", "id": "" };
  newCenterValue: any;
  constructor(
    private http: HttpClient,
    public toastController: ToastController
  ) { }

  ngOnInit() {
    this.panchayat = "";
    this.allCenter = {
      "panchayats": []
    }
    this.newCenterValue =
    {
      "centerName": "string",
      "userName": [

      ],
      "panchayats": [
        "string"
      ],
      "totalCollection": 0,
      "totalSold": 0
    }
    this.storage = JSON.parse(localStorage.getItem("currentUser"));
    this.id = this.storage.userId;
    this.token = this.storage.id;
    this.getUser()
  }

  getUser() {
    this.usercenter = [];
    this.http.get(`${Urls.USERS}/${this.id}?access_token=${this.token}`).subscribe((res: any) => {
      console.log(res)
      this.name = res.username;
      if (res.centers) {
        this.usercenter = res.centers;
      } else {
        this.usercenter = [];
      }

    })
  }

  addpan = function () {
    if (this.allCenter.hasOwnProperty("panchayats")) {
      this.allCenter.panchayats.push(this.panchayat);
      this.flag = true;
      console.log(this.panchayat, this.allCenter)
    } else {

    }
    this.panchayat = "";
  }
  deletepan(i) {
    this.allCenter.panchayats.splice(i, 1);
    if (this.allCenter.panchayats.length <= 0) {
      this.flag = false;
    } else {
      this.flag = true;
    }
    console.log(this.allCenter)
  }
  add(f) {
    // let i = {}
    this.newUser.id = this.id;
    this.newUser.name = this.name;
    this.newCenterValue.centerName = f.value.centerName;
    this.newCenterValue.panchayats = this.allCenter.panchayats;
    this.newCenterValue.userName.push(this.newUser);
    console.log(this.newCenterValue)
    this.http.post<any>(`${Urls.CENTERS}`, this.newCenterValue).subscribe(res => {
      console.log(res)
      let i = res;
      this.usercenter.push(i.id);
      this.http.patch(`${Urls.USERS}/${this.id}?access_token=${this.token}`, { "centers": this.usercenter }).subscribe(res => {
        console.log(res)
        f.reset()
        this.allCenter.panchayats = []
        this.callCenters()
      })

    })
    // this.usercenter.push("newce")
    console.log(f, this.allCenter, this.usercenter, this.newUser, this.newCenterValue)
    f.reset()
    this.allCenter.panchayats = []
  }

  callCenters() {
    this.http.get(`${Urls.CENTERS}`).subscribe(res => {
      console.log(res)
    });
  }
}
