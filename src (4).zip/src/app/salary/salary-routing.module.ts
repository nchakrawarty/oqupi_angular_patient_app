import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddsalaryComponent } from './addsalary/addsalary.component';

import { SalaryPage } from './salary.page';

const routes: Routes = [
  {
    path: '',
    component: SalaryPage
  },
  {
    path: 'add-salary',
    component: AddsalaryComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SalaryPageRoutingModule {}
