export interface Salary {
    amount:number,
    email:string,
    userId:any,
    date:Date,
    payedBy:any
}