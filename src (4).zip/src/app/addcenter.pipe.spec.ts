import { AddcenterPipe } from './addcenter.pipe';

describe('AddcenterPipe', () => {
  it('create an instance', () => {
    const pipe = new AddcenterPipe();
    expect(pipe).toBeTruthy();
  });
});
