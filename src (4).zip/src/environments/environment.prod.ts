export const environment = {
  production: true,
  api_base_url: 'http://35.154.168.2:3000/api'
};
