import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../app/guard/auth.guard';
import { NoauthGuard } from '../app/guard/noauth.guard';

const routes: Routes = [
  // { path: '', loadChildren: () => import('./tabs/tabs.module').then(m => m.TabsPageModule) }
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginPageModule), canActivate: [NoauthGuard] },
  { path: 'tabs', loadChildren: () => import('./tabs/tabs.module').then(m => m.TabsPageModule), canActivate: [AuthGuard] },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then(m => m.RegisterPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'camera',
    loadChildren: () => import('./camera/camera.module').then(m => m.CameraPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'media',
    loadChildren: () => import('./media/media.module').then(m => m.MediaPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'alluserslist',
    loadChildren: () => import('./alluserslist/alluserslist.module').then(m => m.AlluserslistPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'menu',
    loadChildren: () => import('./menu/menu.module').then(m => m.MenuPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'addcenter',
    loadChildren: () => import('./addcenter/addcenter.module').then(m => m.AddcenterPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'moneycollections',
    loadChildren: () => import('./moneycollections/moneycollections.module').then(m => m.MoneycollectionsPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'viewmoneycollection',
    loadChildren: () => import('./viewmoneycollection/viewmoneycollection.module').then(m => m.ViewmoneycollectionPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'view-trips',
    loadChildren: () => import('./trips-view/trips-view.module').then(m => m.TripsViewPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'new',
    loadChildren: () => import('./new/new.module').then(m => m.NewPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'trips',
    loadChildren: () => import('./trips/trips.module').then(m => m.TripsPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'add',
    loadChildren: () => import('./add/add.module').then(m => m.AddPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'trips-view',
    loadChildren: () => import('./trips-view/trips-view.module').then(m => m.TripsViewPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'revenue',
    loadChildren: () => import('./revenue/revenue.module').then(m => m.RevenuePageModule),
    canActivateChild: [AuthGuard],
    canActivate: [AuthGuard]
  },
  {
    path: 'expenses',
    loadChildren: () => import('./expenses/expenses.module').then(m => m.ExpensesPageModule),
    canActivate: [AuthGuard]
  },
  {
    path: 'salary',
    loadChildren: () => import('./salary/salary.module').then(m => m.SalaryPageModule),
    canActivate: [AuthGuard]
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }