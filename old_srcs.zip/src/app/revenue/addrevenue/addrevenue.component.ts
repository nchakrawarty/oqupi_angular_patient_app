import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Router, NavigationExtras } from '@angular/router';

import { ToastController } from '@ionic/angular';
import { Urls } from '../../constants/urls';
import { url } from 'inspector';
import { read } from 'fs';
import { type } from 'os';
import { computeStackId } from '@ionic/angular/directives/navigation/stack-utils';

@Component({
  selector: 'app-addrevenue',
  templateUrl: './addrevenue.component.html',
  styleUrls: ['./addrevenue.component.scss'],
})
export class AddrevenueComponent implements OnInit {

  money = { "amount": "", "collectedBy": "" };
  collection: any = {};
  centerCollection: any;
  customerId: any = null;

  constructor(
    private http: HttpClient,
    private router: Router,
    public toastController: ToastController
  ) { }

  ngOnInit() {
    // this.fetchCenterCollectionData(localStorage.getItem('selectedCenterId'));
  }

  ionViewWillEnter() {
    this.fetchCenterCollectionData(localStorage.getItem('selectedCenterId'));
  }

  // Open menu
    onMenu() {
      this.router.navigate(['/menu']);
    }

  // Back
    back() {
      this.router.navigate(['/revenue']);
    }

  fetchCenterCollectionData(v) {
    this.centerCollection = null;
    this.http.get(`${Urls.CENTERS}/${v}/revenues`).subscribe(res => {
      this.centerCollection = res;
    });
  }

  logForm(collection) {
    if(collection.address &&
      collection.amount &&
      collection.area &&
      collection.date &&
      collection.name &&
      collection.phone &&
      collection.type) {
        this.postCollection(collection);
      } else {
        this.presentToast('Please enter all values', 'danger');
      }
  }

  // Check if a customer already exists, if yes then return user id
  async checkCustomer(phone) {
    this.customerId = null;
    await this.http.get(`${Urls.CUSTOMERS}?filter=%7B"where"%3A%7B"contact"%3A"${phone}"%7D%7D`).subscribe((res:any) => {

      if(res.length > 0) {
        this.customerId = res[0].id;
      }
    })
  }

  async postCollection (collection) {
   console.log(collection);
    this.checkCustomer(collection.phone);
    let userData: any = JSON.parse(localStorage.getItem('currentUser'));
    let user: any = {};
    user.userId = userData.userId;
    user.userName = localStorage.getItem('userName');
    collection.savedBy = user;
    let selectedCenterId = localStorage.getItem('selectedCenterId');

    if(this.customerId === '' || this.customerId === null) {
      const usr =  Object.assign({}, collection) ;
      usr.createdAt = collection.savedOn;
      usr.contact = collection.phone;
      delete user.phone
      delete usr.savedOn;
      delete usr.date;
      user.centerId = selectedCenterId;
      usr.panchayat = localStorage.getItem('selectedPanchayat');

      console.log(usr);
      // await this.http.post(`${Urls.CUSTOMERS}`, usr).subscribe(
      //   (res: any) => { 
      //     collection.customerId = res.id;
      //     console.log("Success saved: ", res);
      //   }
      // )
    } else {
      collection.customerId = this.customerId;
    }
    let currentDate = (new Date()).toISOString().slice(0, 19).replace(/-/g, "/").replace("T", " at ");
    collection.savedOn = currentDate;
    this.http.get(`${Urls.CENTERS}/${selectedCenterId}?filter[fields][centerName]=true`).subscribe(async res => {
      let a: any = res;
      if (this.centerCollection || this.centerCollection != null) {
        console.log("PATCH TO EXISTING DATA");
        this.centerCollection.collection.unshift(this.collection);
        console.log(this.centerCollection);
        this.collection = {};
        // this.http.patch(`${Urls.REVENUE}/${this.centerCollection.id}`, this.centerCollection).subscribe(res => {
        //   this.presentToast('Successfully added', 'success');
        // }, err => { console.log(err) });
      }
      else {
        console.log("NEW ENTRY");
        let temp = {
          "center": "",
          "collection": [],
          "centerId": "",
          "customerId": "" 
        };
        temp.collection.push(collection);
        temp.center = a.centerName;
        temp.centerId = selectedCenterId;

        if(this.customerId === '' || this.customerId === null) {
          const usr = collection;
          usr.createdAt = collection.savedOn;
          usr.contact = collection.phone;
          delete user.phone
          delete usr.savedOn;
          delete usr.date;
          user.centerId = selectedCenterId;
          usr.panchayat = localStorage.getItem('selectedPanchayat');
  
          console.log(usr);
          // await this.http.post(`${Urls.CUSTOMERS}`, usr).subscribe(
          //   (res: any) => { 
          //     temp.customerId = res.id;
          //     console.log("Success saved: ", res);
          //   }
          // )
        }
        else {
          temp.customerId = this.customerId;
        }
        // this.http.post(`${Urls.REVENUE}`, temp).subscribe(
        //   res => {
        //     this.presentToast('Successfully added', 'success');
        //   }, err => {
        //     console.log(err);
        //   });
      }
    }, err => {
      console.log(err);
    });
  }

  async presentToast(d, c) {
    const toast = await this.toastController.create({
      message: d,
      duration: 1000,
      position: 'top',
      cssClass: 'normalToast',
      color: c
    });
    toast.present();
  }

}
