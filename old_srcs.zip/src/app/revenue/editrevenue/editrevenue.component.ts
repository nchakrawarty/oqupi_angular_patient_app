import { Component, Input, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-editrevenue',
  templateUrl: './editrevenue.component.html',
  styleUrls: ['./editrevenue.component.scss'],
})
export class EditrevenueComponent implements OnInit {

  @Input() userData:any;

  collection: any;

  constructor(private viewCtrl: ModalController) { }

  ngOnInit() {
    this.collection = this.userData;
  }

  logForm(collection: any) {
    this.collection = collection;
    // console.log(collection);
    this.dismiss();
  }

  dismiss() {
    this.viewCtrl.dismiss({
      'dismissed': true,
      'data': this.collection
    });
  }

}
