import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RevenuePageRoutingModule } from './revenue-routing.module';

import { RevenuePage } from './revenue.page';
import { AddrevenueComponent } from './addrevenue/addrevenue.component';
import { EditrevenueComponent } from './editrevenue/editrevenue.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RevenuePageRoutingModule
  ],
  declarations: [
    RevenuePage, 
    AddrevenueComponent,
    EditrevenueComponent
  ]
})
export class RevenuePageModule {}
