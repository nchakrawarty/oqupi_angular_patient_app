import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { ActivatedRoute, Router } from '@angular/router';
import { ModalController } from '@ionic/angular';

import { Urls } from '../constants/urls';
import { EditrevenueComponent } from './editrevenue/editrevenue.component';

@Component({
  selector: 'app-revenue',
  templateUrl: './revenue.page.html',
  styleUrls: ['./revenue.page.scss'],
})
export class RevenuePage implements OnInit {

  flag = false;
  id: any;
  data: any;
  savedby: string;
  panchayats:any = [];
  selectedPanchayat:string = null;

  paid = false;

  constructor(
    private http: HttpClient, 
    private route: ActivatedRoute, 
    private router: Router,
    public modalController: ModalController
  ) {
    this.id = localStorage.getItem('selectedCenterId');
  }

  ngOnInit() {
    this.http.get(`${Urls.CENTERS}/${this.id}/revenues`).subscribe(res => {
      this.data = res;
      console.log(res);
      if (this.data.length > 0) {
        this.flag = true;
      }
    });

    this.fetchPanchayats();
  }

  // Fetch All Panchayats in a center
  fetchPanchayats() {
    this.http.get(`${Urls.CENTERS}/${this.id}`).subscribe((res:any) => {
      this.panchayats = res.panchayats;

      if(!localStorage.getItem('selectedPanchayat')) {
        localStorage.setItem('selectedPanchayat', this.panchayats[0]);
      }

      this.selectedPanchayat = localStorage.getItem('selectedPanchayat');
    })
  }

  // Select panchayat option
  select(e) {
    let panchayat = e.target.value;
    this.selectedPanchayat = panchayat;
    localStorage.setItem('selectedPanchayat', this.selectedPanchayat);

  }

   // Open menu
    onMenu() {
      this.router.navigate(['/menu']);
    }

    // Save existing users' data
    saveUserPayment(user) {
      console.log(user);
      this.presentModal(user);
    }

    // Navigate back to Add page
    add() {
      this.router.navigate([`/revenue/add-revenue`]);
    }

    back() {
      this.router.navigate(['/']);
    }

    async presentModal(payment) {
      const modal = await this.modalController.create({
        component: EditrevenueComponent,
        componentProps: {
          'userData': payment
        },
        cssClass: 'my-custom-class'
      },
      );
     modal.onWillDismiss()
      .then((data) => {
        console.log(data.data.data)
      })

      return await modal.present();
    }

    


  

}