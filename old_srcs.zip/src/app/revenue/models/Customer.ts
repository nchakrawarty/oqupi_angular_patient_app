export interface Customer {
    name: string,
    contact: string,
    address: string,
    panchayat: string,
    type: string
}