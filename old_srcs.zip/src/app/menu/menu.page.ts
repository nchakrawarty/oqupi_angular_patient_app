import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from "@angular/common/http";
import { AuthService } from '../auth.service';
import { Urls } from '../constants/urls';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.page.html',
  styleUrls: ['./menu.page.scss'],
})
export class MenuPage implements OnInit {

  role: any;

  constructor(
    private authService: AuthService,
    private http: HttpClient,
    private router: Router
  ) { }

  ngOnInit() {
    this.onLoad();
  }

  onLoad() {
    const storage = JSON.parse(localStorage.getItem("currentUser"));
    console.log(storage);
    const id = storage.userId;
    const token = storage.id;
    this.http.get(`${Urls.USERS}/${id}?access_token=${token}`).subscribe((res: any) => {
      if (res.role === 'admin') {
        this.role = true;
      }
      // this.getCenterData("")
    })
  }

  userList() {
    this.router.navigate(['/alluserslist']);
  }
  register() {
    this.router.navigate(['/register'])
  }
  LogOut() {
    this.authService.logout();
  }
  moneycollections() {
    this.router.navigate(['/moneycollections'])
  }
  revenue() {
    this.router.navigate(['/revenue'])
  }
  expenses() {
    this.router.navigate(['/expenses'])
  }
  trips() {
    this.router.navigate(['/view-trips'])
  }
  addCenter() {
    this.router.navigate(['/addcenter'])
  }
}