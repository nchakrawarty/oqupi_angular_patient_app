export interface Expense {
    name:string,
    type?:string,
    desc:string,
    amount:number,
    centerId:string,
    date:Date
  };