import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Urls } from '../constants/urls';
import { Router } from '@angular/router';
import { ExpenseService } from './shared/expense.service';
import { Expense } from './shared/expense.model';

@Component({
  selector: 'app-expenses',
  templateUrl: './expenses.page.html',
  styleUrls: ['./expenses.page.scss'],
})
export class ExpensesPage implements OnInit {

  center: any = [];
  role: boolean = false;
  centers: any = null;
  month: string;


  selectedCenter: string = null;

  months = ["January", "February", "March", "April", "May", "June", 
            "July", "August", "September", "October", "November", "December"];
  
  expenses:Expense[] = null;
  filteredExpences:Expense[] = null;

  constructor(
    private http: HttpClient, 
    private router: Router,
    private expenseService: ExpenseService
  ) {}

  async ngOnInit() {
    (await this.expenseService.setCenterName()).subscribe((res) => {
      this.center = res;
    })
    let storage:any = await JSON.parse(localStorage.getItem("currentUser"));
    let token:string = storage.id;
    let id:string = storage.userId;
     this.fetchCenters(id, token);
    this.expenses = this.expenseService.getExpenses();
  }

  async ionViewWillEnter(e) {
    this.selectedCenter = localStorage.getItem('selectedCenterId');
    this.expenses = this.expenseService.getExpenses();
    this.getExpense();
  }

  viewAll() {
    let ary:Expense[] = [];
    this.month = '';
    this.filteredExpences = null;
    this.expenses.forEach(expense => {
      if(expense.centerId === localStorage.getItem('selectedCenterId')) {
        ary.push(expense);
      }
    });
    this.filteredExpences = ary;
  }


  fetchCenters(id, token) {
    this.expenseService.fetchCenters(id, token)
      .subscribe((res: any) => {
      
        let allCenterIds: [] = res.centers;
        let selectedCenter = res.centers[0];
        localStorage.setItem('selectedCenterId', selectedCenter);
        if (res.role === 'admin') {
          this.role = true;
          this.getAllCenters(allCenterIds);
        }
        this.ionViewWillEnter("")
      })
  }

  getAllCenters(centerIds) {
    this.centers = [];
    centerIds.forEach(id => {
      this.expenseService.getAllCenters(centerIds, id).subscribe(res => {
        this.centers.push(res);
      });
    });
  }

  getExpense() {
    let id:string = localStorage.getItem('selectedCenterId')
    let ar:Expense[] = [];
    this.filteredExpences = null;
    this.expenses.forEach(expense => {

      if(expense.centerId === id) {
        ar.push(expense);
      }
    });
    // this.expenses = ar;
    this.filteredExpences = ar;
  }

  monthChanged (e:Event) {
    e.preventDefault();
    let dt:string[] = this.month.split('-');
    let monthNumber = parseInt(dt[1]);
    let yearNumber = parseInt(dt[0]);
    
    let filteredData:any = [] ;

    this.getExpense()


    this.filteredExpences.forEach(expense => {
      if(expense.date.getFullYear() === yearNumber && expense.date.getMonth()+1 === monthNumber) {
        filteredData.push(expense);
      }
    });

    this.filteredExpences = filteredData;
  }

  // Open menu
  onMenu() {
    this.router.navigate(['/menu']);
  }

  // Back to home screen
  back() {
    this.router.navigate(['/']);
  }

  select(event) {
    this.month = '';
    this.filteredExpences = this.expenses;
    localStorage.setItem('selectedCenterId', event.detail.value);
    this.ionViewWillEnter("");
  }

  // Navigate back to Add page
  add() {
    this.router.navigate([`/expenses/add-expense`]);
  }

}
