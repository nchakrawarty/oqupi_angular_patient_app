import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { Expense } from '../shared/expense.model';
import { ExpenseService } from '../shared/expense.service';



@Component({
  selector: 'app-addexpense',
  templateUrl: './addexpense.component.html',
  styleUrls: ['./addexpense.component.scss'],
})
export class AddexpenseComponent implements OnInit {

  date: Date = new Date();

  expenses: Expense[];
  expense: Expense = {
    name: null,
    desc: null,
    type: null,
    amount: null,
    centerId: null,
    date: null
  }
  exType: any = [];

  constructor(
    private router: Router,
    private expenseService: ExpenseService,
    private toastController: ToastController
  ) { }

  ngOnInit() {
    this.expenses = this.expenseService.getExpenses();
  }

  ionViewWillEnter() {
    // this.expenseService.getExpenses().subscribe(res => {
    //   this.expenses = res;
    // });
    this.expenses = this.expenseService.getExpenses();
    console.log(this.expenses);
    if (this.expenses) {
      this.expenses.forEach(expense => {
        this.exType.push(expense.name)
      });
      this.exType = [...new Set(this.exType)];
    }
  }

  // back to view expenses page
  back() {
    this.router.navigate(['/expenses']);
  }

  logForm() {
    this.expense.centerId = localStorage.getItem('selectedCenterId');
    if (this.expense.type && this.expense.type !== '') {
      this.expense.name = this.expense.type;
    }
    delete this.expense.type;

    if (this.expense.amount
      && this.expense.centerId
      && this.expense.date
      && this.expense.desc
      && this.expense.name
    ) {
      this.expenseService.postExpense(this.expense).subscribe(res => {
        console.log(res);
        this.presentToast('Successs', 'success');
        this.expense = {
          name: null,
          desc: null,
          type: null,
          amount: null,
          centerId: null,
          date: null
        }
      })
    } else {
      this.presentToast('Please enter all fields', 'danger');
    }

  }


  async presentToast(d, c) {
    const toast = await this.toastController.create({
      message: d,
      duration: 1000,
      position: 'top',
      cssClass: 'normalToast',
      color: c
    });
    toast.present();
  }
  onMenu() {
    // console.log("menu clicked")
    this.router.navigate(['/menu']);
  }

}
