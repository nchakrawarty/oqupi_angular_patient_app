import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addsalary',
  templateUrl: './addsalary.component.html',
  styleUrls: ['./addsalary.component.scss'],
})
export class AddsalaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
