import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AddcenterPageRoutingModule } from './addcenter-routing.module';

import { AddcenterPage } from './addcenter.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AddcenterPageRoutingModule
  ],
  declarations: [AddcenterPage]
})
export class AddcenterPageModule {}
