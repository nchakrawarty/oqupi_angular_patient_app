import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MoneycollectionsPageRoutingModule } from './moneycollections-routing.module';

import { MoneycollectionsPage } from './moneycollections.page';
import { SelectCenterComponent} from '../menu/select-center/select-center.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MoneycollectionsPageRoutingModule
  ],
  declarations: [MoneycollectionsPage, SelectCenterComponent]
})
export class MoneycollectionsPageModule {}
