import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MoneycollectionsPage } from './moneycollections.page';

describe('MoneycollectionsPage', () => {
  let component: MoneycollectionsPage;
  let fixture: ComponentFixture<MoneycollectionsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MoneycollectionsPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MoneycollectionsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
