import { Component, OnInit } from '@angular/core';
import { Urls } from '../constants/urls';
import { HttpClient } from "@angular/common/http";
import { async } from '@angular/core/testing';


@Component({
  selector: 'app-alluserslist',
  templateUrl: './alluserslist.page.html',
  styleUrls: ['./alluserslist.page.scss'],
})
export class AlluserslistPage implements OnInit {
  data: any;
  cen: any;
  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.getAllUser()
  }

  getAllUser() {
    this.http.get(`${Urls.ALLS}`).subscribe(res => {
      console.log(res)
      this.data = res;
      this.data.forEach(element => {
        element.centers.forEach(cen => {
          // this.cen = cen;
          console.log(cen)
          this.getCenter(cen)
          console.log(this.cen)
        })
        console.log(element)
      });
    })
  }
  async getCenter(cen) {
    this.cen = await this.http.get(`${Urls.CENTERS}/${cen}?filter[fields][centerName]=true`).subscribe(res => {
      console.log(res)
    })
  }

}
