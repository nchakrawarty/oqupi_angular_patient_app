import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Router } from "@angular/router";
import { Urls } from '../constants/urls';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-trips',
  templateUrl: './trips.page.html',
  styleUrls: ['./trips.page.scss'],
})
export class TripsPage {

  trip: any = {}

  data: any;

  centerTrips: any;

  month: number;
  year: any;

  errorMessage: string = "";
  
  monthShortNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

  centerId = localStorage.getItem('selectedCenterId');


  constructor( private http: HttpClient, 
    private router: Router,
     public toastController: ToastController ) {
      this.fetchCenterCollectionData(localStorage.getItem('selectedCenterId'));
  }

  ionViewWillEnter() {
    this.month = new Date().getMonth();
    this.year = new Date().getFullYear().toString();
    this.fetchCenterCollectionData(localStorage.getItem('selectedCenterId'));
  }

  fetchCenterCollectionData(v) {
    this.centerTrips = null;
    this.http.get(`${Urls.CENTERS}/${v}/trips`).subscribe(res => {
      this.centerTrips = res;
    });
  }

  // Navigate back to trips page
  back() {
    this.router.navigate([`view-trips`]);
  }


  logForm() {
    let dept = this.trip.dept;
    let arvl = this.trip.arvl;

    if(this.trip.collectionDate && this.trip.name 
      && this.trip.dept && this.trip.arvl 
      && this.trip.numplate && this.trip.remarks) {
        let deptHM = dept.split(':');
        let arvlHM = arvl.split(':');
        this.trip.dept = this.formatTime(deptHM);
        this.trip.arvl = this.formatTime(arvlHM);

        document.getElementById("error-msg").style.display = "none";
        
        this.postForm()
      }
      else {
        document.getElementById("error-msg").style.display = "block";
        this.errorMessage = "Please enter all fields";
      }
    
  }

  formatTime(date) {
	  var hours = date[0];
    hours = parseInt(hours.split('T')[1]);
	  var minutes = date[1];
	  var ampm = hours >= 12 ? 'pm' : 'am';
	  hours = hours % 12;
	  hours = hours ? hours : 12;
	  // minutes = minutes < 10 ? '0'+minutes : minutes;
	  var strTime = hours + ':' + minutes + ' ' + ampm;
	  return strTime;
}

// Save form data to database
  async postForm() {
    let user: any = {};
    let data: any = JSON.parse(localStorage.getItem('currentUser'));


    this.data = this.trip;
    user.userId = data.userId;
    user.userName = localStorage.getItem('userName');
    this.data.savedBy = user;
    this.http.get(`${Urls.CENTERS}/${localStorage.getItem('selectedCenterId')}?filter[fields][centerName]=true`).subscribe(res => {
      let a: any = res;
      if (this.centerTrips || this.centerTrips != null) {
        this.centerTrips.trip.unshift(this.data);
        // let submitForm = (<HTMLInputElement>document.getElementsByName('submit-form')[0]);
        // submitForm.reset();
        this.http.patch(`${Urls.TRIPS}/${this.centerTrips.id}`, this.centerTrips).subscribe(res => {
          this.presentToast('Successfully added', 'success');
          this.reset();
        }, err => { console.log(err) });
      }
      else {
        let temp = {
          "center": "string",
          "trip": [],
          "centerId": "string"
        };
        temp.trip.push(this.data);
        temp.center = a.centerName;
        temp.centerId = localStorage.getItem('selectedCenterId');

        this.http.post(`${Urls.TRIPS}`, temp).subscribe(
          res => {
            this.presentToast('Successfully added', 'success');
          }, err => {
            console.log(err);
          });
      }
    }, err => {
      console.log(err);
    });
  }

  // Reset form
  reset() {
    this.trip = {};
  }

async presentToast(d, c) {
  const toast = await this.toastController.create({
    message: d,
    duration: 1000,
    position: 'top',
    cssClass: 'normalToast',
    color: c
  });
  toast.present();
}

}
