import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { WasteinputComponent } from './wasteinput.component';

describe('WasteinputComponent', () => {
  let component: WasteinputComponent;
  let fixture: ComponentFixture<WasteinputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WasteinputComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(WasteinputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
