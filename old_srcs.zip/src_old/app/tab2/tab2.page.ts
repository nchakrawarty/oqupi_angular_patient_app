import { Component } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { ModalController, NavParams } from '@ionic/angular';
import { WasteinputComponent } from '../wasteinput/wasteinput.component';
import { ToastController } from '@ionic/angular';
import { Urls } from '../constants/urls';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  constructor(
    private http: HttpClient,
    public modalController: ModalController,
    public toastController: ToastController
  ) {
  }
  storage;
  id: string;
  token: string;
  role: boolean = false;
  allCenterIds: [];
  allCenters: any;
  centerData: any;
  wastecollection: any;
  UserCenter: any;
  wasteCollected: any;
  typeOfWaste: any;
  valueOfWaste: any;
  dataReturned: any;
  data: any;
  centersData: any;
  total: number = 0;
  oveAll: number = 0;
  currentDate: String;
  selectedcenter: string;
  weekdays = ["sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

  async ngOnInit() {

    this.centerData = {
      "centerName": "",
      "totalCollection": "",
      "userName": ""
    }
    this.wastecollection = {
      center: "",
      waste: [],
      centerId: ""
    };
    this.typeOfWaste = [

      {
        "name": "Plastic",
        "value": 0
      },
      {
        "name": "Paper",
        "value": 0
      },
      {
        "name": "Metal",
        "value": 0
      },
      {
        "name": "Glass",
        "value": 0
      },
      {
        "name": "Other dry waste",
        "value": 0
      },
      {
        "name": "Vegetable & fruit peels",
        "value": 0
      },
      {
        "name": "Egg shells",
        "value": 0
      },
      {
        "name": "Chicken & fish bones",
        "value": 0
      },
      {
        "name": "Rotten fruits & vegetables",
        "value": 0
      },
      {
        "name": "Tissue paper soiled with food",
        "value": 0
      },
      {
        "name": "Tea bags & Coffee grinds",
        "value": 0
      },
      {
        "name": "Leaf plates",
        "value": 0
      }
    ];
    this.valueOfWaste = [];
    console.log("Storage : ", localStorage);
    this.storage = await JSON.parse(localStorage.getItem("currentUser"));
    this.id = this.storage.userId;
    this.token = this.storage.id;
    this.getUserCenters();
  }


  getUserCenters() {
    this.http.get(`${Urls.USERS}/${this.id}?access_token=${this.token}`).subscribe((res: any) => {
      this.allCenterIds = res.centers;
      if(localStorage.getItem('selectedCenterId').length <= 0) {
        this.UserCenter = res.centers[0];
      }
      else {
        this.UserCenter = localStorage.getItem('selectedCenterId');
      }
      
      localStorage.setItem('selectedCenterId', this.UserCenter);
      if (res.role === 'admin') {
        this.role = true;
        this.getAllCenters();
      }
      // this.fetchCenterData(localStorage.getItem('selectedCenterId'));
      this.ionViewWillEnter("")
    })
  }

  ionViewWillEnter(e) {
    // console.log(localStorage);
    this.wasteCollected = {
      "day": "",
      "date": "",
      "totalShift": 0,
      "totalwaste": 0,
      "waste": []
    }
    this.fetchCenterData(localStorage.getItem('selectedCenterId'), e);
    this.selectedcenter = localStorage.getItem('selectedCenterId');
    // this.onChange(localStorage.getItem('selectedCenterId'))
    this.currentDate = new Date().toISOString();
  }

  fetchCenterData(v, e) {
    this.http.get(`${Urls.CENTERS}/${v}`).subscribe(res => {
      this.centersData = res;
      this.fetchData(v, e);
    });
  }

  onChange(v) {
    console.log(v.detail.value)
    localStorage.setItem('selectedCenterId', v.detail.value);
    // this.fetchCenterData(v.detail.value, "");
    this.ionViewWillEnter("")
  }

  getAllCenters() {
    this.allCenters = [];
    this.allCenterIds.forEach(id => {
      this.http.get(`${Urls.CENTERS}/${id}`).subscribe(res => {
        this.allCenters.push(res);
      });
    });
  }

  fetchData(v, e) {
    this.data = null;
    // console.log(v)
    this.http.get(`${Urls.CENTERS}/${v}/wastecollecteds`).subscribe(res => {
      this.data = res;
      // console.log(this.data)
      this.data.waste.forEach(item => {
        item.waste.forEach(collectedwaste => {
          this.total += collectedwaste.value;
        });
      });
      if (e) {
        e.target.complete();
      }
    }, err => { e.target.complete() });
  }

  saveCenterData() {
    this.wasteCollected.day = this.weekdays[new Date().getDay()];
    this.wasteCollected.date = (new Date()).toISOString().slice(0, 19).replace(/-/g, "/").replace("T", " at ");
    this.http.get(`${Urls.CENTERS}/${localStorage.getItem('selectedCenterId')}`).subscribe(res => {
      this.centerData = res;
      console.log("while saving, centerData value =>", this.centerData)
      if (this.valueOfWaste.length > 0) {
        if (this.data || this.data != null) {
          console.log("data avail", this.data, this.UserCenter, localStorage.getItem('selectedCenterId'));
          this.wasteCollected.savedBy = localStorage.getItem('userName');
          this.data.waste.unshift(this.wasteCollected);
          this.centerData.totalCollection = parseFloat(this.centerData.totalCollection) + this.wasteCollected.totalwaste;
          console.log(this.centerData, this.wasteCollected)
          // this.centerData.wasteCollected.unshift(this.wasteCollected);
          this.wastecollection.center = this.centerData.centerName;
          this.wastecollection.centerId = this.centerData.id;
          console.log(this.data.waste);
          this.http.patch(`${Urls.WASTE}/${this.data.id}`, this.data).subscribe(res => {
            this.http.patch(`${Urls.CENTERS}/${localStorage.getItem('selectedCenterId')}`, { "totalCollection": this.centerData.totalCollection }).subscribe(res => {
              for (var i = 0; i < this.typeOfWaste.length; i++) {
                this.typeOfWaste[i].value = 0;
              }
              this.valueOfWaste = [];
              this.presentToast('Successfully added', 'success')
              this.ionViewWillEnter("")

            })
          }, err => { console.log(err) });
        } else {
          console.log("no data", this.UserCenter, localStorage.getItem('selectedCenterId'))
          let temp = {
            "center": "string",
            "waste": [],
            "centerId": "string"
          };
          this.wasteCollected.savedBy = localStorage.getItem('userName');
          temp.waste.push(this.wasteCollected);
          temp.centerId = localStorage.getItem('selectedCenterId');
          temp.center = this.centerData.centerName;
          this.centerData.totalCollection = parseFloat(this.centerData.totalCollection) + this.wasteCollected.totalwaste;
          this.http.post(`${Urls.WASTE}`, temp).subscribe(res => {
            this.http.patch(`${Urls.CENTERS}/${localStorage.getItem('selectedCenterId')}`, { "totalCollection": this.centerData.totalCollection }).subscribe(res => {
              for (var i = 0; i < this.typeOfWaste.length; i++) {
                this.typeOfWaste[i].value = 0;
              }

              this.valueOfWaste = [];
              this.presentToast('Successfully added', 'success');
              this.ionViewWillEnter("")
            })
          }, err => {
            console.log(err)
          })
        }
        this.fetchCenterData(localStorage.getItem('selectedCenterId'), "");
      } else {
        this.presentToast('Please add atleast one data to add', 'danger')
      }
    },
      err => {
        console.log(err)
        this.presentToast('Connection error, check internet', 'danger')
      })
  }

  onClickSaveData() {
    this.wasteCollected.waste = this.valueOfWaste;
    for (var i = 0; i < this.valueOfWaste.length; i++) {
      this.wasteCollected.totalwaste = parseFloat(this.wasteCollected.totalwaste) + parseFloat(this.valueOfWaste[i].value);
      console.log(this.valueOfWaste[i].value, this.wasteCollected.totalwaste)
    }
    // for (var j = 0; j < this.wasteCollected.length; j++) {
    //   this.oveAll = + parseFloat(this.wasteCollected[i].totalwaste);
    // }
    // console.log(this.wasteCollected)
    if (this.valueOfWaste.length > 0) {
      this.saveCenterData()
    } else { this.presentToast('Please add atleast one data to add', 'danger') }

  }

  modal(e, w) {
    // console.log(w)
    this.presentModal(w)
  }

  async presentModal(w) {
    console.log(w)
    const modal = await this.modalController.create({
      component: WasteinputComponent,
      componentProps: w
    });
    modal.onDidDismiss().then((dataReturned) => {
      if (dataReturned !== null && dataReturned.data !== undefined) {
        this.dataReturned = dataReturned.data;
        console.log(this.valueOfWaste.length)
        if (this.valueOfWaste.length > 0) {
          let count = -1;
          for (var i = 0; i < this.valueOfWaste.length; i++) {
            if (this.valueOfWaste[i].name == dataReturned.data.name) {
              count = i;
            }
          }
          if (count >= 0) {
            this.valueOfWaste[count].value = dataReturned.data.value;
          } else {
            this.valueOfWaste.push(dataReturned.data)
          }
          console.log("New waste collection", this.valueOfWaste)

        } else {
          this.valueOfWaste.push(dataReturned.data)
          console.log("New waste collection", this.valueOfWaste)

        }
        w.value = dataReturned.data.value;
      }
    });
    return await modal.present();
  }
  async presentToast(d, c) {
    const toast = await this.toastController.create({
      message: d,
      duration: 1000,
      position: 'top',
      cssClass: 'normalToast',
      color: c
    });
    toast.present();
  }
  doRefresh(event) {
    console.log('Begin async operation');
    this.ionViewWillEnter(event)
    this.wasteCollected = null
    setTimeout(() => {
      console.log('Async operation has ended');
      // event.target.complete();
    }, 2000);
  }
}
