import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../app/guard/auth.guard';
import { NoauthGuard } from '../app/guard/noauth.guard';

const routes: Routes = [
  // { path: '', loadChildren: () => import('./tabs/tabs.module').then(m => m.TabsPageModule) }
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginPageModule), canActivate: [NoauthGuard] },
  { path: 'tabs', loadChildren: () => import('./tabs/tabs.module').then(m => m.TabsPageModule), canActivate: [AuthGuard] },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then(m => m.RegisterPageModule)
  },
  {
    path: 'camera',
    loadChildren: () => import('./camera/camera.module').then(m => m.CameraPageModule)
  },
  {
    path: 'media',
    loadChildren: () => import('./media/media.module').then(m => m.MediaPageModule)
  },
  {
    path: 'alluserslist',
    loadChildren: () => import('./alluserslist/alluserslist.module').then(m => m.AlluserslistPageModule)
  },
  {
    path: 'menu',
    loadChildren: () => import('./menu/menu.module').then(m => m.MenuPageModule)
  },
  {
    path: 'addcenter',
    loadChildren: () => import('./addcenter/addcenter.module').then(m => m.AddcenterPageModule)
  },
  {
    path: 'moneycollections',
    loadChildren: () => import('./moneycollections/moneycollections.module').then(m => m.MoneycollectionsPageModule)
  },
  {
    path: 'viewmoneycollection',
    loadChildren: () => import('./viewmoneycollection/viewmoneycollection.module').then(m => m.ViewmoneycollectionPageModule)
  },
  {
    path: 'view-trips',
    loadChildren: () => import('./trips-view/trips-view.module').then(m => m.TripsViewPageModule)
  },
  {
    path: 'new',
    loadChildren: () => import('./new/new.module').then(m => m.NewPageModule)
  },
  {
    path: 'trips',
    loadChildren: () => import('./trips/trips.module').then( m => m.TripsPageModule)
  },
  {
    path: 'add',
    loadChildren: () => import('./add/add.module').then( m => m.AddPageModule)
  },
  {
    path: 'trips-view',
    loadChildren: () => import('./trips-view/trips-view.module').then( m => m.TripsViewPageModule)
  }
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
