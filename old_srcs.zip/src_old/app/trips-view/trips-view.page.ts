import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { ActivatedRoute, Router } from '@angular/router';
import { Urls } from '../constants/urls';

@Component({
  selector: 'app-view-trips',
  templateUrl: './trips-view.page.html',
  styleUrls: ['./trips-view.page.scss'],
})
export class TripsViewPage {

  flag = false;
  id: any;
  allTrips: any = null;
  data: any = null;
  savedby: string;
  collection: any = null;

  singleTrip: any = null;
  index = 0;

  trip: any;
  collectionDate: string;

  storage: any;
  allCenterIds: [];
  allCenters: any;
  selectedcenter: string;
  token: string;
  role: boolean = false;

  centerTrips: any;

  constructor(private http: HttpClient, private route: ActivatedRoute, private router: Router) {
  }

  /** START CENTER SELECTION **/

  async ngOnInit() {
    this.storage = await JSON.parse(localStorage.getItem("currentUser"));
    this.id = this.storage.userId;
    this.token = this.storage.id;
    this.getUserCenters();
  }

  ionViewWillEnter(e) {
    let id = localStorage.getItem('selectedCenterId');
    this.data = null;
    this.http.get(`${Urls.CENTERS}/${id}/trips`).subscribe(res => {
      this.data = res;

      console.log(this.data);

      // this.trip = this.formatTime();
      this.collectionDate = this.formatTime();

      // this.trip = this.data.trip[0].collectionDate;
      this.setAllTrips(res);
      this.logForm(this.collectionDate);
      if (this.data && this.data.length > 0) {
        this.flag = true;
      }
    });
  }

  getUserCenters() {
    this.http.get(`${Urls.USERS}/${this.id}?access_token=${this.token}`).subscribe((res: any) => {
      this.allCenterIds = res.centers;
      localStorage.setItem('selectedCenterId', res.centers[0]);
      if (res.role === 'admin') {
        this.role = true;
        this.getAllCenters();
      }
      // this.fetchCenterData(localStorage.getItem('selectedCenterId'));
      this.ionViewWillEnter("")
    })
  }

  onChange(v) {
    console.log(v.detail.value)
    localStorage.setItem('selectedCenterId', v.detail.value);
    // this.fetchCenterData(v.detail.value, "");
    this.ionViewWillEnter("")
  }
  
  getAllCenters() {
    this.allCenters = [];
    this.allCenterIds.forEach(id => {
      this.http.get(`${Urls.CENTERS}/${id}`).subscribe(res => {
        this.allCenters.push(res);
      });
    });
  }

  /** END CENTER SELECTION **/

  formatTime() {
    const todayDate = new Date();
    let month = (todayDate.getMonth()+1).toString();
    var a = todayDate.toString();
    const date = a.split(' ');
    if(parseInt(month) < 10 ){
      month = '0' + month;
    }

	  var finalDate = date[3]+'-'+month+'-'+date[2];
    return finalDate
}


// Set all trips in the center
setAllTrips(res: {}) {
  this.allTrips = Object.assign({}, res);
}

// Get all trips in the center
getAllTrips() {
  return this.allTrips;
}

// Navigate back to Add page
back() {
  this.router.navigate([`tabs/add`]);
}

// Navigate back to Add page
add() {
  this.router.navigate([`tabs/trips`]);
}

// Open menu
onMenu() {
  this.router.navigate(['/menu']);
}

// Filter trips by Collection date
logForm(collectionDate) {
    this.collectionDate = collectionDate;
  console.log(this.data);
  let allData: any = [];
      this.data.trip.forEach( (trip) => {
        
        if(trip.collectionDate === this.collectionDate){
          allData.push(trip);
        }
      });
      if(allData && allData.length>0) {
        this.allTrips.trip = allData;
        this.singleTrip = allData;
      }
      else {
        this.allTrips.trip = null;
        this.singleTrip = null;
      }

}

// Update Tabs
updateTab(index) {
  this.index = index;
}
  
}