import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { TripsViewPageRoutingModule } from './trips-view-routing.module';

import { TripsViewPage } from './trips-view.page';

import { TripDetailsComponent } from './trip-details/trip-details.component';

import { SelectCenterComponent } from '../menu/select-center/select-center.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    TripsViewPageRoutingModule
  ],
  declarations: [TripsViewPage, TripDetailsComponent, SelectCenterComponent]
})
export class TripsViewPageModule {}
