export const environment = {
  production: true,
  api_base_url: 'http://52.66.196.163:3000/api'
};
