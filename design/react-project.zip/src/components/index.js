import Pxtest from './Pxtest';

export default { Pxtest };
