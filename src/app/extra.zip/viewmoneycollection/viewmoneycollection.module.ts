import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ViewmoneycollectionPageRoutingModule } from './viewmoneycollection-routing.module';

import { ViewmoneycollectionPage } from './viewmoneycollection.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ViewmoneycollectionPageRoutingModule
  ],
  declarations: [ViewmoneycollectionPage]
})
export class ViewmoneycollectionPageModule {}
