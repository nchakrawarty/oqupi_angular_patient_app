import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ExpensesPageRoutingModule } from './expenses-routing.module';

import { ExpensesPage } from './expenses.page';
import { AddexpenseComponent } from './addexpense/addexpense.component';
import { ExpenseService } from './shared/expense.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ExpensesPageRoutingModule
  ],
  declarations: [ExpensesPage, AddexpenseComponent],
  providers: [ExpenseService]
})
export class ExpensesPageModule {}
