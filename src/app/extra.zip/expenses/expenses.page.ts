import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ExpenseService } from './shared/expense.service';
import { Expense } from './shared/expense.model';

@Component({
  selector: 'app-expenses',
  templateUrl: './expenses.page.html',
  styleUrls: ['./expenses.page.scss'],
})
export class ExpensesPage implements OnInit {


  center: any = [];
  role: boolean = false;
  centers: any = null;
  month: string = null;


  selectedCenter: string = null;

  expenses:any;
  filteredExpences:Expense[] = null;

  constructor(
    private router: Router,
    private expenseService: ExpenseService
  ) {}

  async ngOnInit() {
    let storage:any = await JSON.parse(localStorage.getItem("currentUser"));
    let token:string = storage.id;
    let id:string = storage.userId;
    this.fetchCenters(id, token);
  }

  async ionViewWillEnter() {
    this.selectedCenter = localStorage.getItem('selectedCenterId');
    this.expenses = [];
    this.filteredExpences = [];
    await this.expenseService.setCenterName().subscribe(res => {
      this.center = res;
    });
    this.getAllExpenses();
  }

  // Fetch all center Ids for the user
  fetchCenters(id, token) {
    this.expenseService.fetchCenters(id, token)
      .subscribe((res: any) => {
      
        let allCenterIds: [] = res.centers;
        let selectedCenter = res.centers[0];
        localStorage.setItem('selectedCenterId', selectedCenter);
        if (res.role === 'admin') {
          this.role = true;
          this.getAllCenters(allCenterIds);
        }
        this.ionViewWillEnter();
      })
  }

  // Get center names
  getAllCenters(centerIds) {
    this.centers = [];
    centerIds.forEach(id => {
      this.expenseService.getAllCenters(id).subscribe(res => {
        this.centers.push(res);
      });
    });
  }

  // Get all expenses for the selected center
  async getAllExpenses() {
    await this.expenseService.getExpenses().subscribe((res: any) => {
      if(res && res.expenses) {
        this.expenses = res.expenses;
        this.filteredExpences = res.expenses;
      } else {
        this.expenses = null;
        this.filteredExpences = null;
      }
    });
  }

  // View all expenses
  viewAll() {
    this.filteredExpences = this.expenses;
    this.month = '';
  }


  // Filter when month changed
  monthChanged () {
    let dt:string[] = this.month.split('-');
    let monthNumber = parseInt(dt[1]);
    let yearNumber = parseInt(dt[0]);
    
    let filteredData:any = [] ;
    this.filteredExpences = this.expenses;

    this.filteredExpences.forEach(expense => {
      let exDt = new Date(expense.date);
      if(exDt.getFullYear() === yearNumber && exDt.getMonth()+1 === monthNumber) {
        filteredData.push(expense);
      }
    });

    this.filteredExpences = filteredData;
  }

  selectCenter(event) {
    this.month = '';
    this.filteredExpences = this.expenses;
    localStorage.setItem('selectedCenterId', event.detail.value);
    this.ionViewWillEnter();
  }

  // Navigate to add expenses component
  add() {
    this.router.navigate([`/expenses/add-expense`]);
  }

  // Open menu
  onMenu() {
    this.router.navigate(['/menu']);
  }
  
  // Back to home screen
  back() {
    this.router.navigate(['/']);
  }
  
}
