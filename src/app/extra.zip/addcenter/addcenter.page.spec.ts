import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AddcenterPage } from './addcenter.page';

describe('AddcenterPage', () => {
  let component: AddcenterPage;
  let fixture: ComponentFixture<AddcenterPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddcenterPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AddcenterPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
