import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddrevenueComponent } from './addrevenue/addrevenue.component';

import { RevenuePage } from './revenue.page';

const routes: Routes = [
  {
    path: '',
    component: RevenuePage
  },
  {
    path: 'add-revenue',
    component: AddrevenueComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RevenuePageRoutingModule {}
