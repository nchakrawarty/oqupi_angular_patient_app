import { Component, Input, OnInit } from '@angular/core';
import { ModalController, ToastController } from '@ionic/angular';
import { Collection } from '../shared/Collection';

@Component({
  selector: 'app-editrevenue',
  templateUrl: './editrevenue.component.html',
  styleUrls: ['./editrevenue.component.scss'],
})
export class EditrevenueComponent implements OnInit {

  @Input() userData:any;

  collection: Collection = {
    engname: null,
    kannadaname: null,
    contact: null,
    address: null,
    area: null,
    amount: null,
    panchayat: null,
    type: null,
    doorno: null,
    editDate: null,
    createdAt: null,
    id: null,
    centerId: null,
    savedBy: null,
    paid: false,
  };


  constructor(
    private viewCtrl: ModalController,
    private toastController: ToastController
  ) {}

  ngOnInit() {
    // this.collection = Object.assign({}, this.userData);
  }

  logForm() {
    this.submit();
  }

  submit() {
    if(this.userData.editDate 
      && this.userData.revenue.amount 
      && this.userData.engname 
      && this.userData.kannadaname 
      && this.userData.phone 
      && this.userData.address
      && this.userData.doorno 
      && this.userData.area 
      && this.userData.revenue.amount 
      && this.userData.type) {
      this.collection = Object.assign({}, this.userData);
      this.viewCtrl.dismiss({
        'dismissed': true,
        'data': this.collection
      });
    } else {
      this.presentToast('Please input all values', 'danger');
    }
  }

  dismiss() {
    this.viewCtrl.dismiss({
      'dismissed': true
    });
  }


  async presentToast(d, c) {
    const toast = await this.toastController.create({
      message: d,
      duration: 1000,
      position: 'top',
      cssClass: 'normalToast',
      color: c
    });
    toast.present();
  }

}
