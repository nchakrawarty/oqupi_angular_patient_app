import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Router } from '@angular/router';

import { ToastController } from '@ionic/angular';
import { Urls } from '../../constants/urls';
import { RevenueService } from '../shared/revenue.service';

@Component({
  selector: 'app-addrevenue',
  templateUrl: './addrevenue.component.html',
  styleUrls: ['./addrevenue.component.scss'],
})
export class AddrevenueComponent implements OnInit {

  money = { "amount": "", "collectedBy": "" };
  collection: any = {};
  centerCollection: any;
  customerId: any = null;

  panchayats: any = null;
  id: string = '';

  constructor(
    private http: HttpClient,
    private router: Router,
    private revenueService: RevenueService,
    public toastController: ToastController
  ) { }

  ngOnInit() {
    this.id = this.revenueService.getCenterId();
    // this.fetchCenterCollectionData(localStorage.getItem('selectedCenterId'));
  }

  ionViewWillEnter() {
    this.fetchPanchayats();
    // this.fetchCenterCollectionData(localStorage.getItem('selectedCenterId'));
  }

  // Open menu
    onMenu() {
      this.router.navigate(['/menu']);
    }

  // Back
    back() {
      this.router.navigate(['/revenue']);
    }

  fetchCenterCollectionData(v, id) {
    this.centerCollection = null;
    this.http.get(`${Urls.CENTERS}/${v}/customers/${id}/revenues`).subscribe(res => {
      this.centerCollection = res;
    });
  }

  // Fetch Panchayats in a Center
  fetchPanchayats() {
    this.http.get(`${Urls.CENTERS}/${this.id}`).subscribe((res:any) => {
      this.panchayats = res.panchayats;
      this.collection.panchayat = localStorage.getItem('selectedPanchayat');
    })
  }

  logForm(collection) {
    if(collection.address &&
      collection.amount &&
      collection.area &&
      collection.date &&
      collection.engname &&
      collection.kannadaname &&
      collection.doorno &&
      collection.phone &&
      collection.type) {
        this.checkCustomer(collection);
      } else {
        this.presentToast('Please enter all values', 'danger');
      }
  }

  // Check if a customer already exists, if yes then return user id
  async checkCustomer(collection) {
    this.customerId = null;
    await this.http.get(`${Urls.CUSTOMERS}?filter=%7B"where"%3A%7B"contact"%3A"${collection.phone}"%7D%7D`)
    .subscribe((res:any) => {
      console.log(res);
      if(res.length > 0) {
        this.customerId = res[0].id;
      }
      this.postCollection(collection);
    })
  }

  async postCollection (collection) {

    let userData: any = JSON.parse(localStorage.getItem('currentUser'));
    let user: any = {};
    user.userId = userData.userId;
    user.userName = localStorage.getItem('userName');
    collection.savedBy = user;
    let selectedCenterId = localStorage.getItem('selectedCenterId');

    // Check if customer already exists in Customer collection
    // Set customer id accordingly
    if(this.customerId === '' || this.customerId === null) {
      const usr =  Object.assign({}, collection) ;
      usr.createdAt = collection.savedOn;
      usr.contact = collection.phone;
      delete user.phone
      delete usr.savedOn;
      delete usr.date;
      usr.createdAt = new Date();
      usr.centerId = selectedCenterId;
      usr.panchayat = localStorage.getItem('selectedPanchayat');
      delete usr.amount;

      
      await this.revenueService.postCustomers(usr).subscribe(
        (res: any) => { 
          collection.customerId = res.id;
        }
      );
    } else { 
      console.log('Existing User');
      collection.customerId = this.customerId;
    }
    collection.centerId = localStorage.getItem('selectedCenterId');
    let date = collection.date.split('-');

    console.log(collection);
    this.http.get(`${Urls.CENTERS}/${selectedCenterId}/customers/${this.customerId}/revenues`)
    .subscribe(
      (res:any) => {
        let flg:boolean = false;
        res.forEach(itm => {
          let dt = itm.date.split('-');
          console.log(dt, date);
          if(parseInt(dt[0]) <= parseInt(date[0]) && parseInt(dt[1]) < parseInt(date[1])) {
            flg = true;
          } else {
            flg = false;
          }
          console.log("Flag: ", flg);
        });
        if(flg) {
            // this.revenueService.postRevenues(collection).subscribe(
            //   res => console.log(res)
            // );
          console.log('New Revenue of Existing customer');
        } else {
          console.log('Already Paid');
        }
      },
      (err) => {
        console.log(err);
        // this.revenueService.postRevenues(collection).subscribe(
        //   res => {console.log('success'); console.log(res); this.collection = {};}
        // );
      }
    )
  }

  async presentToast(d, c) {
    const toast = await this.toastController.create({
      message: d,
      duration: 1000,
      position: 'top',
      cssClass: 'normalToast',
      color: c
    });
    toast.present();
  }

}
