import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'revenue'
})
export class RevenuePipe implements PipeTransform {

  transform(value: any, ...args: any): any {
    if(!args[0]) {
      return value;
    } else if(value) {
      return value.filter(user => {
        return JSON.stringify(user).toLowerCase().includes(args[0].toLowerCase());
      });
    }
  }

}
