export interface Collection {
    engname: string,
    kannadaname: string,
    contact: string,
    address: string,
    area: string,
    amount?: number,
    panchayat: string,
    type: string,
    doorno: string,
    editDate: Date,
    createdAt: Date,
    id: string,
    centerId: string,
    savedBy?: object,
    paid: boolean,


}