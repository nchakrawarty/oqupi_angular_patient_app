export interface Customer {
    engname: string,
    kannadaname: string,
    contact: string,
    address: string,
    area: string,
    amount: number,
    panchayat: string,
    type: string,
    doorno: string,
    editDate: Date,
    createdAt: Date,
    id: string,
    centerId: string,
    revenue?:object
}