import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RevenuePageRoutingModule } from './revenue-routing.module';

import { RevenuePage } from './revenue.page';
import { AddrevenueComponent } from './addrevenue/addrevenue.component';
import { EditrevenueComponent } from './editrevenue/editrevenue.component';
import { RevenueService } from './shared/revenue.service';
import { RevenuePipe } from './shared/revenue.pipe';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RevenuePageRoutingModule
  ],
  declarations: [
    RevenuePage, 
    AddrevenueComponent,
    EditrevenueComponent,
    RevenuePipe
  ],
  providers: [
    RevenueService
  ]
})
export class RevenuePageModule {}
