import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-trip-details',
  templateUrl: './trip-details.component.html',
  styleUrls: ['./trip-details.component.scss'],
})
export class TripDetailsComponent implements OnInit {

  @Input() singleTrip: {};

  @Input() index: number;

  @Input() date: {};

  constructor() { 
  }

  ngOnInit() {
    // console.log(this.singleTrip);
  }

}
