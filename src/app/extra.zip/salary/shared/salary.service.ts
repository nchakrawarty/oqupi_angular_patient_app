import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Urls } from 'src/app/constants/urls';

@Injectable({
  providedIn: 'root'
})
export class SalaryService {

  constructor(
    private http: HttpClient
  ) { }

  // Get selected center id
  getSelectedCenterId(): string {
    return localStorage.getItem('selectedCenterId');
  }

  // Get users
  getUsers() {
    let id = localStorage.getItem('selectedCenterId');
    return this.http.get(`${Urls.CENTERS}/${id}/Alls`)
  }

  // Get all centersIDs for a user
  getUserCenters(id, token) {
    return this.http.get(`${Urls.USERS}/${id}?access_token=${token}`);
  }

  // Get center by id
  getCenterById(id) {
    return this.http.get(`${Urls.CENTERS}/${id}`);
  }

  // Get all salaries in a center
  getSalaries(id) {
    return this.http.get(`${Urls.ALLS}/${id}/salaries`);
  }

  fetchCenters(id, token) {
    return this.http.get(`${Urls.USERS}/${id}?access_token=${token}`);
  }

  // Post salary data
  postSalary(salary) {
    return this.http.post(Urls.SALARY, salary);
  }

  // Patch salary data
  patchSalary(salary) {
    let id = salary.id;
    delete salary.id;
    return this.http.patch(`${Urls.SALARY}/${id}`, salary);
  }

  getAllCenters(id) {
    return this.http.get(`${Urls.CENTERS}/${id}`);
  }

}
