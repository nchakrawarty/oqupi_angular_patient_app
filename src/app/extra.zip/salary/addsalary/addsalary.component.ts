import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { Salary } from '../shared/salary.model';
import { SalaryService } from '../shared/salary.service';

@Component({
  selector: 'app-addsalary',
  templateUrl: './addsalary.component.html',
  styleUrls: ['./addsalary.component.scss'],
})
export class AddsalaryComponent implements OnInit {
  salary: Salary = {
    amount: null,
    email: null,
    userId: null,
    date: null,
    payedBy: {}
  };

  user:any = null;

  selectedCenterId: string = localStorage.getItem("selectedCenterId")? localStorage.getItem("selectedCenterId") : null;
  selectedCenterName:string = null;

  users: any = null;
  selectedUser: any = null;
  role: boolean = false;
  centers: any= null;

  userName:string = null;

  constructor(
    private salaryService: SalaryService,
    public toastController: ToastController,
    private router: Router
  ) { }

  async ngOnInit() {
    let storage:any = await JSON.parse(localStorage.getItem("currentUser"));
    console.log(storage);
    let token:string = storage.id;
    let id:string = storage.userId;
    this.fetchCenters(id, token);
  }

  ionViewWillEnter() {
    this.selectedCenterId = localStorage.getItem('selectedCenterId');
    this.getUsers();
  }

  // Get All users in a center
  getUsers() {
    this.salaryService.getUsers().subscribe(res => {
      this.users = res;
    });
  }

  // Fetch all center Ids for the user
  fetchCenters(id, token) {
    this.salaryService.fetchCenters(id, token)
      .subscribe((res: any) => {
        this.salary.payedBy.id = res.id;
        this.salary.payedBy.name = res.username;
        let allCenterIds: [] = res.centers;
        let selectedCenter = res.centers[0];
        localStorage.setItem('selectedCenterId', selectedCenter);
        if (res.role === 'admin') {
          this.role = true;
          this.getAllCenters(allCenterIds);
        }
        this.ionViewWillEnter();
      })
  }

  // Get center names
  getAllCenters(centerIds) {
    this.centers = [];
    centerIds.forEach(id => {
      this.salaryService.getAllCenters(id).subscribe((res:any) => {
        if(res.id === this.selectedCenterId){
          this.selectedCenterName = res.centerName
        }
        this.centers.push(res);
      });
    });

  }

  // Set Center Name
  setCenterName() {
    // console.log(this.centers);
    this.centers.forEach(center => {
      // console.log(center.id, this.selectedCenterId)
      if(center.id === this.selectedCenterId) {
        this.selectedCenterName = center.centerName;
      }
    });
  }

  select(event) {
    this.selectedCenterId = event.target.value;
    localStorage.setItem('selectedCenterId', this.selectedCenterId);
    this.setCenterName();
    this.getUsers();
  }

  back() {
    this.router.navigate(['/salary']);
  }

  onMenu() {
    this.router.navigate(['/menu']);
  }

  logForm() {
    if(this.salary.date && this.salary.amount) {
      this.submitForms();
    } else {
      this.presentToast('Please enter all values', 'danger');
    }
  }

  submitForms() {
    this.salary.email = this.user.email;
    this.salary.userId = this.user.userid;
    let salaryObj:any = {
      salaries: null,
      allId: this.user.id
    };
    this.salaryService.getSalaries(this.user.id)
      .subscribe(
          (res: any) => {
            salaryObj.salaries = (res.salaries);
            salaryObj.salaries.unshift(this.salary);
            salaryObj.id = res.id;
            // this.salaryService.patchSalary(salaryObj);
            this.salaryService.patchSalary(salaryObj)
            .subscribe(res => {
              this.presentToast('Successfully added', 'success');
            });
          },
          err => {
            if(err.status === 404) {
              salaryObj.salaries = this.salary;
              this.salaryService.postSalary(salaryObj).subscribe(
                (res:any) => {
                  this.presentToast('Successfully added', 'success');
                }
              )
            }
          } 
        );
  }

  async presentToast(d, c) {
    const toast = await this.toastController.create({
      message: d,
      duration: 1000,
      position: 'top',
      cssClass: 'normalToast',
      color: c
    });
    toast.present();
  }

}
