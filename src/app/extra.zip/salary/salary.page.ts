import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SalaryService } from './shared/salary.service';

@Component({
  selector: 'app-salary',
  templateUrl: './salary.page.html',
  styleUrls: ['./salary.page.scss'],
})
export class SalaryPage implements OnInit {

  salaries: any = null;
  filteredSalaries: any =null;
  role:boolean = false;
  centers: any = null;
  selectedCenter: string = null;

  month:string = null;

  constructor(
    private salaryService: SalaryService,
    private router: Router
  ) { }

  async ngOnInit() {
    let storage:any = await JSON.parse(localStorage.getItem("currentUser"));
    let token:string = storage.id;
    let id:string = storage.userId;
    this.fetchUserCenters(id, token);
  }

  async ionViewWillEnter() {
    this.selectedCenter = localStorage.getItem('selectedCenterId');
    this.salaries = [];
    this.filteredSalaries = [];
    this.getSalaries();
  }

  // Fetch all centers associated with the user
  fetchUserCenters(id, token) {
    this.salaryService.getUserCenters(id, token).subscribe(
      (res: any) => {
        if(res.role === 'admin') {
          this.role = true;
        }
      let centers = res.centers;
      this.getAllCenters(centers);
    });
  }

  // Get center names
  getAllCenters(centerIds) {
    let centers = [];
    centerIds.forEach(async id => {
      await this.salaryService.getCenterById(id).subscribe(
        (res: any) => {
          centers.push(res);
        }
      )
    });
    this.centers = centers;
  }

  // Get all salaries
  async getSalaries() {
    let users = null;
    let salaries:any = [];
    this.salaryService.getUsers().subscribe(res => {
      users = res;
      users.forEach(async user => {
        this.salaryService.getSalaries(user.id)
        .subscribe((item:any) => {
          salaries.push(item.salaries);
        });
      });
      this.salaries = salaries;
      this.filteredSalaries = this.salaries;
    });

  }

  // Filter when month changed
  monthChanged () {
    let dt:string[] = this.month.split('-');
    let monthNumber = parseInt(dt[1]);
    let yearNumber = parseInt(dt[0]);

    let filteredData:any = [] ;
    this.filteredSalaries = this.salaries[0];

    this.filteredSalaries.forEach(salary => {
      let exDt = new Date(salary.date);
      if(exDt.getFullYear() === yearNumber && exDt.getMonth()+1 === monthNumber) {
        filteredData.push(salary);
      }
    });
    this.filteredSalaries = [];
    this.filteredSalaries.push(filteredData);
  }

  // Navigate to add salary component
  add() {
    this.router.navigate([`/salary/add-salary`]);
  }

  back() {
    this.router.navigate([`/`]);
  }

  onMenu() {
    this.router.navigate([`/menu`]);
  }

  logForm() {}

  selectCenter(event) {
    localStorage.setItem('selectedCenterId', event.target.value);
    this.month = '';
    this.getSalaries();
  }

}
