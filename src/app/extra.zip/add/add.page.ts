import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Router } from "@angular/router";
import { ModalController, NavParams } from '@ionic/angular';
import { WasteinputComponent } from '../wasteinput/wasteinput.component';
import { ToastController } from '@ionic/angular';
import { Urls } from '../constants/urls';

@Component({
  selector: 'app-add',
  templateUrl: './add.page.html',
  styleUrls: ['./add.page.scss'],
})
export class AddPage implements OnInit {

  storage;
  id: string;
  token: string;
  role: boolean = false;
  centerData: any;
  wastecollection: any;
  UserCenter: any;
  wasteCollected: any;
  typeOfWaste: any;
  valueOfWaste: any;
  dataReturned: any;
  data: any;
  centersData: any;
  total: number = 0;
  oveAll: number = 0;
  currentDate: String;

  allCenterIds: [];
  allCenters: any;
  selectedcenter: string;

  constructor( 
      private http: HttpClient,
      private router: Router,
      public modalController: ModalController,
      public toastController: ToastController 
    ) { }

  async ngOnInit() {
    this.storage = await JSON.parse(localStorage.getItem("currentUser"));
    this.id = this.storage.userId;
    this.token = this.storage.id;
    this.getUserCenters();
  }

  ionViewWillEnter(e) {
    this.selectedcenter = localStorage.getItem('selectedCenterId');
    // this.onChange(localStorage.getItem('selectedCenterId'))
    this.currentDate = new Date().toISOString();
  }

  // Navigate to Add Trips, View Trips page or Tab2
  navigate(path) {
      this.router.navigate([`tabs/${path}`]);
    }

  getUserCenters() {
    this.http.get(`${Urls.USERS}/${this.id}?access_token=${this.token}`).subscribe((res: any) => {
      this.allCenterIds = res.centers;
      this.UserCenter = res.centers[0];
      localStorage.setItem('selectedCenterId', this.UserCenter);
      if (res.role === 'admin') {
        this.role = true;
        this.getAllCenters();
      }
      // this.fetchCenterData(localStorage.getItem('selectedCenterId'));
      this.ionViewWillEnter("")
    })
  }

  getAllCenters() {
    this.allCenters = [];
    this.allCenterIds.forEach(id => {
      this.http.get(`${Urls.CENTERS}/${id}`).subscribe(res => {
        this.allCenters.push(res);
      });
    });
  }

  onChange(v) {
    localStorage.setItem('selectedCenterId', v.detail.value);
    this.ionViewWillEnter("")
  }

}
