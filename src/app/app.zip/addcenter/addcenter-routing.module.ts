import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddcenterPage } from './addcenter.page';

const routes: Routes = [
  {
    path: '',
    component: AddcenterPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AddcenterPageRoutingModule {}
