import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { AlluserslistPage } from './alluserslist.page';

describe('AlluserslistPage', () => {
  let component: AlluserslistPage;
  let fixture: ComponentFixture<AlluserslistPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlluserslistPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(AlluserslistPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
