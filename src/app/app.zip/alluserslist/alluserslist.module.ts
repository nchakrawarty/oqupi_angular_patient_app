import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AlluserslistPageRoutingModule } from './alluserslist-routing.module';

import { AlluserslistPage } from './alluserslist.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    AlluserslistPageRoutingModule
  ],
  declarations: [AlluserslistPage]
})
export class AlluserslistPageModule {}
