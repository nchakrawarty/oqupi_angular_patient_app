import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { ActivatedRoute, Router } from '@angular/router';

import { Urls } from '../constants/urls';

@Component({
  selector: 'app-viewmoneycollection',
  templateUrl: './viewmoneycollection.page.html',
  styleUrls: ['./viewmoneycollection.page.scss'],
})
export class ViewmoneycollectionPage implements OnInit {
  flag = false;
  id: any;
  data: any;
  savedby: string;
  constructor(private http: HttpClient, private route: ActivatedRoute, private router: Router) {
    this.route.queryParams.subscribe(params => {
      if (params && params.id) {
        this.id = JSON.parse(params.id);
      }
    });
  }

  ngOnInit() {
    console.log(localStorage);
    this.http.get(`${Urls.CENTERS}/${this.id}/moneycollections`).subscribe(res => {
      this.data = res;
      if (this.data.length > 0) {
        this.flag = true;
      }
      console.log(this.data);
    });
  }

  back() {
    this.router.navigate(['moneycollections']);
  }

}
