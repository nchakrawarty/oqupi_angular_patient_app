import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ViewmoneycollectionPage } from './viewmoneycollection.page';

describe('ViewmoneycollectionPage', () => {
  let component: ViewmoneycollectionPage;
  let fixture: ComponentFixture<ViewmoneycollectionPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewmoneycollectionPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ViewmoneycollectionPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
