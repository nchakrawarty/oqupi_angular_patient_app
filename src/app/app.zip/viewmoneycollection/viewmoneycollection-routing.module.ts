import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ViewmoneycollectionPage } from './viewmoneycollection.page';

const routes: Routes = [
  {
    path: '',
    component: ViewmoneycollectionPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ViewmoneycollectionPageRoutingModule {}
