import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Router, NavigationExtras } from '@angular/router';

import { ToastController } from '@ionic/angular';
import { Urls } from '../constants/urls';

@Component({
  selector: 'app-moneycollections',
  templateUrl: './moneycollections.page.html',
  styleUrls: ['./moneycollections.page.scss'],
})
export class MoneycollectionsPage implements OnInit {

  money = {};
  collection: any;
  centerCollection: any;

  constructor(
    private http: HttpClient,
    private router: Router,
    public toastController: ToastController
  ) { }

  ngOnInit() {
    // this.fetchCenterCollectionData(localStorage.getItem('selectedCenterId'));
  }

  ionViewWillEnter() {
    this.fetchCenterCollectionData(localStorage.getItem('selectedCenterId'));
  }

  fetchCenterCollectionData(v) {
    this.centerCollection = null;
    this.http.get(`${Urls.CENTERS}/${v}/moneycollections`).subscribe(res => {
      this.centerCollection = res;
      console.log(this.centerCollection);
    });
  }

  logForm() {
    let user: any = {};
    let data: any = JSON.parse(localStorage.getItem('currentUser'));
    this.collection = this.money;
    user.userId = data.userId;
    user.userName = localStorage.getItem('userName');
    this.collection.savedBy = user;
    let currentDate = (new Date()).toISOString().slice(0, 19).replace(/-/g, "/").replace("T", " at ");
    this.collection.date = currentDate;
    this.http.get(`${Urls.CENTERS}/${localStorage.getItem('selectedCenterId')}?filter[fields][centerName]=true`).subscribe(res => {
      let a: any = res;
      if (this.centerCollection || this.centerCollection != null) {
        this.centerCollection.collection.unshift(this.collection);
        console.log(this.centerCollection);
        this.http.patch(`${Urls.MONEYCOLLECT}/${this.centerCollection.id}`, this.centerCollection).subscribe(res => {
          this.presentToast('Successfully added', 'success');
        }, err => { console.log(err) });
      }
      else {
        let temp = {
          "center": "string",
          "collection": [],
          "centerId": "string"
        };
        temp.collection.push(this.collection);
        temp.center = a.centerName;
        temp.centerId = localStorage.getItem('selectedCenterId');
        // console.log(temp);
        this.http.post(`${Urls.MONEYCOLLECT}`, temp).subscribe(
          res => {
            this.presentToast('Successfully added', 'success');
          }, err => {
            console.log(err);
          });
      }
    }, err => {
      console.log(err);
    });
  }

  viewData() {
    let navigationExtras: NavigationExtras = {
      queryParams: {
        id: JSON.stringify(localStorage.getItem('selectedCenterId'))
      }
    };
    console.log(navigationExtras)
    this.router.navigate(['/viewmoneycollection'], navigationExtras);
  }

  async presentToast(d, c) {
    const toast = await this.toastController.create({
      message: d,
      duration: 1000,
      position: 'top',
      cssClass: 'normalToast',
      color: c
    });
    toast.present();
  }

}
