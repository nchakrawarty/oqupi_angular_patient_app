import { Component } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Urls } from '../constants/urls';
import { AuthService } from '../auth.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss']
})
export class TabsPage {
  currentUserName: any;
  storage;
  id: string;
  token: string;
  role: any;
  UserCenter: any;

  constructor(
    private authService: AuthService,
    private http: HttpClient, private router: Router
  ) {
    // this.role = "";
    this.onLoad()
  }

  async ngOnInit() {
    this.storage = await JSON.parse(localStorage.getItem("currentUser"));
    this.id = this.storage.userId;
    this.token = this.storage.id;
    this.getUserCenters();
  }

  onLoad() {
    console.log("from tabs")
    this.storage = JSON.parse(localStorage.getItem("currentUser"));
    console.log(this.storage);
    this.id = this.storage.userId;
    this.token = this.storage.id;
    this.http.get(`${Urls.USERS}/${this.id}?access_token=${this.token}`).subscribe((res: any) => {
      if (res.role === 'admin') {
        this.role = true;
      }
      // this.getCenterData("")
    })
  }
  onMenu() {
    console.log("menu clicked")
    this.router.navigate(['/menu']);
  }
  onLogout() {
    this.authService.logout();
  }

  getUserCenters() {
    this.http.get(`${Urls.USERS}/${this.id}?access_token=${this.token}`).subscribe((res: any) => {
      console.log(res)
      this.UserCenter = res.centers[0];
      localStorage.setItem('selectedCenterId', this.UserCenter);
    })
  }
}
