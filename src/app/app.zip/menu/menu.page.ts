import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.page.html',
  styleUrls: ['./menu.page.scss'],
})
export class MenuPage implements OnInit {

  constructor(private authService: AuthService, private router: Router) { }

  ngOnInit() {
  }
  userList() {
    this.router.navigate(['/alluserslist']);
  }
  register() {
    this.router.navigate(['/register'])
  }
  LogOut() {
    this.authService.logout();
  }
  moneycollections() {
    this.router.navigate(['/moneycollections'])
  }
  addCenter() {
    this.router.navigate(['/addcenter'])
  }
}
