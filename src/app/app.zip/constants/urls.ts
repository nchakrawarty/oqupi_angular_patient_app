

import { environment } from '../../environments/environment';

export class Urls {
    private static BASE_URL: string = environment.api_base_url;

    public static readonly CENTERS = `${Urls.BASE_URL}/centers`;
    public static readonly LOGIN = `${Urls.BASE_URL}/Users/login`;
    public static readonly USERS = `${Urls.BASE_URL}/Users`;
    public static readonly FILES = `${Urls.BASE_URL}/files`;
    public static readonly ALLS = `${Urls.BASE_URL}/Alls`;
    public static readonly WASTE = `${Urls.BASE_URL}/wastecollecteds`;
    public static readonly MONEYCOLLECT = `${Urls.BASE_URL}/moneycollections`;
}
