import { Component } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { ModalController, NavParams } from '@ionic/angular';
// import { WasteinputComponent } from '../wasteinput/wasteinput.component';
import { ToastController } from '@ionic/angular';
import { Urls } from '../constants/urls';
import { $ } from 'protractor';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {
  constructor(
    private http: HttpClient,
    public modalController: ModalController,
    public toastController: ToastController,
    private authService: AuthService,
  ) {
  }
  storage;
  id: string;
  token: string;
  centerData: any;
  centersData: any;
  UserCenter: any;
  wasteCollected: any;
  wastecollection: any;
  typeOfWaste: any;
  valueOfWaste: any;
  dataReturned: any;
  data: any;
  total: number = 0;
  oveAll: number = 0;

  currentDate: String;
  weekdays = ["sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

  async ngOnInit() {
    this.centerData = {
      "centerName": "",
      "totalCollection": "",
      "userName": "",
      "wasteCollected": []
    }
  }

  LogOut() {
    this.authService.logout();
  }
  doRefresh(event) {
    this.ngOnInit();
    setTimeout(() => {
      console.log('Async operation has ended');
      event.target.complete();
    }, 2000);

  }
  async presentToast(d, c) {
    const toast = await this.toastController.create({
      message: d,
      duration: 1000,
      position: 'top',
      cssClass: 'normalToast',
      color: c
    });
    toast.present();
  }
}