import { Component } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Urls } from '../constants/urls';
import { LoadingController, ToastController } from '@ionic/angular';
import { AuthService } from '../auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import {
  ApexAxisChartSeries,
  ApexTitleSubtitle,
  ApexChart,
  ApexXAxis,
  ApexYAxis,
  ApexFill,
  ChartComponent,
  ApexStroke,
  ApexMarkers,
  ApexNonAxisChartSeries,
  ApexResponsive,
  ApexDataLabels,
  ApexLegend
} from "ng-apexcharts";
import { stringify } from '@angular/compiler/src/util';
export type ChartOptions = {
  series: ApexAxisChartSeries;
  //  | ApexNonAxisChartSeries;
  piseries: ApexNonAxisChartSeries;
  chart: ApexChart;
  title: ApexTitleSubtitle;
  stroke: ApexStroke;
  fill: ApexFill;
  markers: ApexMarkers;
  xaxis: ApexXAxis;
  yaxis: ApexYAxis;
  responsive: ApexResponsive[];
  labels: any;
  legend: ApexLegend;
  dataLabels: ApexDataLabels;
};
export type ChartOptions1 = {
  series: ApexNonAxisChartSeries;
  chart: ApexChart;
  title: ApexTitleSubtitle;
  stroke: ApexStroke;
  fill: ApexFill;
  markers: ApexMarkers;
  xaxis: ApexXAxis;
  yaxis: ApexYAxis;
  responsive: ApexResponsive[];
  labels: any;
  legend: ApexLegend;
  dataLabels: ApexDataLabels;
};
@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})

export class Tab1Page {
  flag = false;
  user: any = JSON.parse(localStorage.getItem('currentUser'));
  loggedInUser: string;

  constructor(
    private authService: AuthService,
    private http: HttpClient, private router: Router,
    private loadingCtrl: LoadingController,
    public toastController: ToastController
  ) {
    // LoopBackConfig.setBaseURL("http://192.168.0.117:3000");
    while (this.colors.length < 100) {
      do {
        var color = Math.floor((Math.random() * 1000000) + 1);
      } while (this.colors.indexOf(color) >= 0);
      this.colors.push("#" + ("ffffff"/* + color.toString(16)*/).slice(-6));
    }

  }
  storage;
  id: string;
  token: string;
  centerData: any;
  UserCenter: any;
  w: any;
  role: any;
  maxNegXValue: string;
  maxNegYValue: string;
  maxPosXValue: string;
  maxPosYValue: string;
  sessionDateTime: string;
  sessionNumber: number;
  examRoomMaxNegXValue: string;
  examRoomMaxNegYValue: string;
  examRoomMaxPosXValue: string;
  examRoomMaxPosYValue: string;
  totalTimeSpent: any;
  upTime: number;
  downTime: number;
  leftTime: number;
  rightTime: number;
  rotation = [{ "label": "Left Rotation", "val": "any", "name": "maxNegXValue", "date": "", "img": "Headtopleft.svg" }, { "label": "Right Rotation", "val": "any", "name": "maxPosXValue", "date": "", "img": "Headtopright.svg" }, { "label": "Cervical Flexion", "val": "any", "name": "maxNegYValue", "date": "", "img": "Headlookingdown.svg" }, { "label": "Cervical Extension", "val": "any", "name": "maxPosYValue", "date": "", "img": "Headlookingtop.svg" }
  ];
  session: any;
  colors = [];
  selectedSession: any;
  sessionLength: number;
  public chartOptions: Partial<ChartOptions>;
  public chartOptions1: Partial<ChartOptions>;
  selectedSessionid: any;
  async ngOnInit() {
    this.http.get(`${Urls.SESSIONS}`).subscribe((res: any) => {
      console.log(res);
      this.session = res;
      this.sessionLength = res.length;
      this.selectedSession = res[res.length - 1];
      this.selectedSessionid = res[res.length - 1].id;
      this.id = res.id;
      this.callSession(this.selectedSessionid);
      /*--------------------------------Game value---------------------- */

      // this.maxNegXValue = parseFloat(this.selectedSession.maxNegXValue).toFixed(2);
      // this.maxNegYValue = parseFloat(this.selectedSession.maxNegYValue).toFixed(2);
      // this.maxPosXValue = parseFloat(this.selectedSession.maxPosXValue).toFixed(2);
      // this.maxPosYValue = parseFloat(this.selectedSession.maxPosYValue).toFixed(2);

      /*-------------------------------- END ---------------------------------------*/


      /*--------------------------------Examination value---------------------- */

      this.examRoomMaxNegXValue = parseFloat(this.selectedSession.examRoomMaxNegXValue).toFixed(2);
      this.examRoomMaxNegYValue = parseFloat(this.selectedSession.examRoomMaxNegYValue).toFixed(2);
      this.examRoomMaxPosXValue = parseFloat(this.selectedSession.examRoomMaxPosXValue).toFixed(2);
      this.examRoomMaxPosYValue = parseFloat(this.selectedSession.examRoomMaxPosYValue).toFixed(2);

      /*-------------------------------- END ---------------------------------------*/
      this.sessionDateTime = this.selectedSession.sessionDateTime;
      this.sessionNumber = this.selectedSession.sessionNumber;
      this.rotationChange();
      console.log(this.selectedSession)


    })
  }
  rotationChange() {
    for (var i = 0; i < this.rotation.length; i++) {
      console.log(i)
      if (i == 0) {
        this.rotation[i].val = this.maxNegXValue;
        this.rotation[i].date = this.session.sessionDateTime;

      } else if (i == 1) {
        this.rotation[i].date = this.session.sessionDateTime;
        this.rotation[i].val = this.maxPosXValue;

      } else if (i == 2) {
        this.rotation[i].date = this.session.sessionDateTime;
        this.rotation[i].val = this.maxNegYValue;

      } else {
        this.rotation[i].date = this.session.sessionDateTime;
        this.rotation[i].val = this.maxPosYValue;

      }
    }
  }

  onChange(s) {
    console.log(s)
    this.callSession(s);
  }
  async callSession(s) {
    const loading = await this.loadingCtrl.create({
      message: 'Loading data'
    });
    this.http.get(`${Urls.SESSIONS + "/" + s}`).subscribe(async (res: any) => {
      console.log(res);
      this.id = res.id;
      this.selectedSession = res;
      this.maxNegXValue = parseFloat(res.maxNegXValue).toFixed(2);
      this.maxNegYValue = parseFloat(res.maxNegYValue).toFixed(2);
      this.maxPosXValue = parseFloat(res.maxPosXValue).toFixed(2);
      this.maxPosYValue = parseFloat(res.maxPosYValue).toFixed(2);
      this.sessionDateTime = res.sessionDateTime;
      this.sessionNumber = res.sessionNumber;
      this.totalTimeSpent = (this.selectedSession.heatMapPosY.length + this.selectedSession.heatMapPosX.length + this.selectedSession.heatMapNegY.length + this.selectedSession.heatMapNegX.length);
      this.upTime = this.selectedSession.heatMapPosY.length;
      this.downTime = this.selectedSession.heatMapNegY.length;
      this.leftTime = this.selectedSession.heatMapNegX.length;
      this.rightTime = this.selectedSession.heatMapPosX.length;
      loading.dismiss();
      this.rotationChange();
      this.chartOptions = {
        series: [
          {
            name: "Session" + this.sessionNumber,
            data: [this.selectedSession.maxNegXValue, this.selectedSession.maxNegYValue, this.selectedSession.maxPosXValue, this.selectedSession.maxPosYValue]
          },
          {
            name: "Session average",
            data: [this.selectedSession.maxNegXValue + 50, this.selectedSession.maxNegYValue + 20, this.selectedSession.maxPosXValue + 10, this.selectedSession.maxPosYValue + 25]
          }
        ],
        chart: {
          height: 350,
          type: "radar",
          dropShadow: {
            enabled: true,
            blur: 1,
            left: 1,
            top: 1
          },
          foreColor: '#ffffff'
        },
        markers: {
          size: 5,
          hover: {
            size: 10
          }
        },
        title: {
          text: "Neck Rotation",
          style: {
            color: "#fff"
          }
        },
        // yaxis: {
        //   show: true, 
        //   labels: {
        //     show: true,
        //     style: {
        //       colors: this.colors
        //     }
        //   },
        //   title: {
        //     text: "Y-axis",
        //     style: {
        //       color: "#ffffff"
        //     }
        //   },
        // },
        xaxis: {
          categories: ["Up", "Right", "Down", "Left"],
          labels: {
            style: {
              colors: this.colors
            }
          }
        },
      }

      this.chartOptions1 = {
        series: [this.selectedSession.heatMapPosY.length, this.selectedSession.heatMapPosX.length, this.selectedSession.heatMapNegY.length, this.selectedSession.heatMapNegX.length],
        chart: {
          id: "chartTime",
          width: 380,
          type: "donut",
          foreColor: '#ffffff'
        },
        title: {
          text: "Time wheel",
          style: {
            color: "#fff"
          }
        },
        labels: ["Extension", "Right", "Flexion", "Left"],

        dataLabels: {
          enabled: true
        },
        fill: {
          type: "gradient"
        },
        legend: {
          show: true,
          position: "bottom",
        },
        responsive: [
          {
            breakpoint: 480,
            options: {
              chart: {
                width: "100%"
              },

            }
          }
        ]
      };


    })
    loading.present();
  }

  onLogout() {
    this.authService.logout();
  }

  doRefresh(event) {
    this.ngOnInit();
    setTimeout(() => {
      console.log('Async operation has ended');
      event.target.complete();
    }, 2000);

  }
  close() {
    this.flag = false;
  }
  edit(d, i) {
    console.log(d, i)
  }
  ionViewWillEnter() {
    this.ngOnInit()
  }

}