import { Component } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { LoadingController, ModalController, NavParams } from '@ionic/angular';
import { ToastController } from '@ionic/angular';
import { Urls } from '../constants/urls';
import { NavigationExtras, Router } from '@angular/router';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  constructor(
    private http: HttpClient,
    public modalController: ModalController,
    public toastController: ToastController,
    private loadingCtrl: LoadingController,
    private router: Router
  ) {
  }
  storage;
  id: string;
  token: string;
  role: boolean = false;
  session: any;
  heatMapNegX: [];
  heatMapNegY: [];
  heatMapPosX: [];
  heatMapPosY: [];
  maxNegXValue: string;
  maxNegYValue: string;
  maxPosXValue: string;
  maxPosYValue: string;
  examRoomMaxNegXValue: string;
  examRoomMaxNegYValue: string;
  examRoomMaxPosXValue: string;
  examRoomMaxPosYValue: string;
  rotation = [{ "label": "Left Rotation", "val": "any", "name": "maxNegXValue", "date": "", "img": "Headtopleft.svg" }, { "label": "Right Rotation", "val": "any", "name": "maxPosXValue", "date": "", "img": "Headtopright.svg" }, { "label": "Cervical Flexion", "val": "any", "name": "maxNegYValue", "date": "", "img": "Headlookingdown.svg" }, { "label": "Cervical Extension", "val": "any", "name": "maxPosYValue", "date": "", "img": "Headlookingtop.svg" }
  ];
  sessionDateTime: string;
  sessionNumber: number;
  sessionLength: number;
  weekdays = ["sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  selectedSession: any;
  selectedSessionid: any;
  async ngOnInit() {
    this.http.get(`${Urls.SESSIONS}`).subscribe((res: any) => {
      console.log(res);
      this.session = res;
      this.sessionLength = res.length;
      this.selectedSession = res[res.length - 1];
      this.selectedSessionid = res[res.length - 1].id;
      console.log(this.selectedSession);
      this.id = res.id;
      /*--------------------------------Game value---------------------- */

      this.maxNegXValue = parseFloat(this.selectedSession.maxNegXValue).toFixed(2);
      this.maxNegYValue = parseFloat(this.selectedSession.maxNegYValue).toFixed(2);
      this.maxPosXValue = parseFloat(this.selectedSession.maxPosXValue).toFixed(2);
      this.maxPosYValue = parseFloat(this.selectedSession.maxPosYValue).toFixed(2);

      /*-------------------------------- END ---------------------------------------*/


      /*--------------------------------Examination value---------------------- */

      this.examRoomMaxNegXValue = parseFloat(this.selectedSession.examRoomMaxNegXValue).toFixed(2);
      this.examRoomMaxNegYValue = parseFloat(this.selectedSession.examRoomMaxNegYValue).toFixed(2);
      this.examRoomMaxPosXValue = parseFloat(this.selectedSession.examRoomMaxPosXValue).toFixed(2);
      this.examRoomMaxPosYValue = parseFloat(this.selectedSession.examRoomMaxPosYValue).toFixed(2);

      /*-------------------------------- END ---------------------------------------*/

      this.sessionDateTime = this.selectedSession.sessionDateTime;
      this.sessionNumber = this.selectedSession.sessionNumber;
      this.rotationChange();
    })
  }
  rotationChange() {
    for (var i = 0; i < this.rotation.length; i++) {
      console.log(i)
      if (i == 0) {
        this.rotation[i].val = this.maxNegXValue;
        this.rotation[i].date = this.session.sessionDateTime;

      } else if (i == 1) {
        this.rotation[i].date = this.session.sessionDateTime;
        this.rotation[i].val = this.maxPosXValue;

      } else if (i == 2) {
        this.rotation[i].date = this.session.sessionDateTime;
        this.rotation[i].val = this.maxNegYValue;

      } else {
        this.rotation[i].date = this.session.sessionDateTime;
        this.rotation[i].val = this.maxPosYValue;

      }
    }
  }
  onChange(s) {
    console.log(s)
    this.callSession(s);
  }
  async callSession(s) {
    const loading = await this.loadingCtrl.create({
      message: 'Loading data'
    });
    this.http.get(`${Urls.SESSIONS + "/" + s}`).subscribe(async (res: any) => {
      console.log(res);
      this.id = res.id;
      this.selectedSession = res;
      this.maxNegXValue = parseFloat(res.maxNegXValue).toFixed(2);
      this.maxNegYValue = parseFloat(res.maxNegYValue).toFixed(2);
      this.maxPosXValue = parseFloat(res.maxPosXValue).toFixed(2);
      this.maxPosYValue = parseFloat(res.maxPosYValue).toFixed(2);
      this.examRoomMaxNegXValue = parseFloat(res.examRoomMaxNegXValue).toFixed(2);
      this.examRoomMaxNegYValue = parseFloat(res.examRoomMaxNegYValue).toFixed(2);
      this.examRoomMaxPosXValue = parseFloat(res.examRoomMaxPosXValue).toFixed(2);
      this.examRoomMaxPosYValue = parseFloat(res.examRoomMaxPosYValue).toFixed(2);
      this.sessionDateTime = res.sessionDateTime;
      this.sessionNumber = res.sessionNumber;
      loading.dismiss();
      this.rotationChange();

    })
    loading.present();
  }

  details() {
    console.log(this.selectedSession.id, this.selectedSession.sessionNumber);
    let navigationExtras: NavigationExtras = {
      state: {
        selectedSession: this.selectedSession
      }
    };
    this.router.navigate(['tabs/details'], navigationExtras);
  }

  async presentToast(d, c) {
    const toast = await this.toastController.create({
      message: d,
      duration: 1000,
      position: 'top',
      cssClass: 'normalToast',
      color: c
    });
    toast.present();
  }
  doRefresh(event) {
    this.ngOnInit();
    setTimeout(() => {
      console.log('Async operation has ended');
      event.target.complete();
    }, 2000);
  }

  // async presentLoading() {
  //   const loading = await this.loadingCtrl.create({
  //     cssClass: 'my-custom-class',
  //     message: 'Please wait...',
  //     duration: 2000
  //   });
  //   await loading.present();

  //   await loading.onDidDismiss();
  //   console.log('Loading dismissed!');
  // }
}
